import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * @author Calvin Villanueva
 * @version 09/15/2023
 * <p>
 * Driver class for the project. main is primarily in charge of handling and parsing the data from countries1.csv and
 * storing the data onto an array with a fixed size of 128 (as specified on project1.pdf) once the user provides the file
 * name. Once the data is stored in the array, the program prompts the user to a repeating menu to select the type of sorting
 * Algorithm they wish to perform.
 * </p>
 * <p>
 * <b> Project 1 uses the newly updated "Countries1.csv" uploaded on 09/13/2023 to eliminate the possibilities of ties during the Kendall Tau calculations.</b>
 * </p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing
 * 	<li><b>Insertion Sort</b> - Ch.3 - part 2 (Slide 6)
 * 	<li><b>Selection Sort</b> - Ch.3 - part 1 (Slide 26)
 * 	<li><b>Bubble Sort</b> - Ch.3 - part 1 (Slide 12)
 * 	<li><b>Binary Search</b> - Ch.2 (slide 26)
 * 	<li><b>Sequential Search</b> - Ch.2 (slide 30)
 * 	<li><b>Kendall Tau</b> - Project 1 PDF 
 *  </li><b>Kendall Tau - (Apache.commmons)</b> - https://commons.apache.org/proper/commons-math/javadocs/api-3.6.1/org/apache/commons/math3/stat/correlation/KendallsCorrelation.html
 * <ol>
 * <p>
 */
public class Project1 
{
	/**
	 * <b>This is the main function of project 1</b>
	 * <p>
	 * The main function is the driver class for project1 and is predominantly in charge 3 main components of Project1.
	 * </p>
	 * First it prompts the user to enter a file name to locate in order to parse it into an array. For this project, it will be "Countries1.csv". 
	 * Once a correct filename is received it skips the first line containing the header and uses a delimiter to know when a new line is detected within the CSV file
	 * <p>
	 * secondly, it then uses a while loop to read and store each record in the file onto an array. Once the end of the file is reached, the scanner
	 * is closed and the array is now fully populated.
	 * </p>
	 * <p>
	 * then lastly, we can present the user with a repeating menu until the user selects the 7th option
	 * from this menu, the user can choose which sorting operation they would like to perform, based on their selection, a boolean flag is used to
	 * determine if the array has been sorted based on the name to use in order to determine the sorting algorithm for option 5.
	 * </p>
	 * 
	 * The main function contains error handling when it comes to the user inputing an invalid file name and an invalid menu choice selection
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		//Array we will store in
		Country[] country = new Country[128];
		//iterator and counter to verify we have 128 countries total
		int recordCount = 0;
		
		Scanner input = new Scanner(System.in);
		//Prompt User for file name
		System.out.println("Please enter the name of the file to open (Countries1.csv) ");
		String fileName = input.next();
		System.out.println("Opening File: " + fileName);
		Scanner file = null;

		
		try
		{
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)//catch for invalud input
		{
			System.out.println("Error the file name entered cannot be found");
			System.exit(1);
			input.close();
		}
		
		file.nextLine();//skip the header!
		file.useDelimiter(",|\n");
		
		while(file.hasNext())//loop to fill array
		{
			String name = file.next();
			String capital = file.next();
			double pop = file.nextDouble();
			double GDP = file.nextDouble();
			double area = file.nextDouble();
			double hapIndex = file.nextDouble();
			
			//store country at index value of recordCount
			country[recordCount] = new Country(name, capital, pop, GDP, area, hapIndex);
			recordCount++;
		}
		file.close();//close scanner
		Scanner scanner = new Scanner(System.in);
		int option = 0;//variable to store option value of the user
		boolean sorted = false; //boolean flag to determine search strategy for option 5 (Binary/Sequential search)
		do
		{
			//prompt menu for user to select option until 7 is selected
			MenuPrinter.menu(recordCount);
			
			try
			{
				option = scanner.nextInt();
				System.out.println("Option Selected: " + option);
			}
			catch(InputMismatchException e)//catch input that may not be digit
			{
				System.out.println("Invalid Option Selection, please enter a numeric value");
				scanner.next();
				option = 0;
			}
			
			if(option == 1)//print all the countries in this option
			{
				Option1.printCountry(country);
				//reset option value back to 0
				option = 0;
			}
			if(option == 2)//sort the names of the countries in ascending order using Insertion Sort.
			{
				//if this option is the last selected before selecting option 5 (search) then the list is sorted.
				//else the list is considered not sorted.
				Option2.sortName(country);
				sorted = true;
				System.out.println("Countries sorted by name using Insertion Sort");
				option = 0;
			}
			if(option == 3)//sort the countries based on happiness index in ascending order using Selection Sort
			{
				Option3.sortHappiness(country);
				//not sorted based on name so set boolean flag to false
				sorted = false;
				System.out.println("Countries sorted by happiness index using Selection Sort");
				option = 0;
			}
			if(option == 4)//sort the countries based on GDPPC ranking using Bubble Sort
			{
				Option4.sortGDP(country);
				//not sorted based on name so boolean flag is still false
				sorted = false;
				System.out.println("Countries sorted by GDP using Bubble Sort.");
				option = 0;
			}
			
			if(option == 5)//Search and Find the given country's information
			{
				//pass the value of boolean flag "sorted" to use to determine if array is sorted.
				Option5.find(country,sorted);
				option = 0;
			}
			
			if(option == 6)//KendallTau Correlation Calculation
			{
				Option6.kendallTau(country);
				option = 0;
				
			}
			if(option == 7)//user selected the 7th menu option closing the program.
			{
				System.out.println("Thank you and goodbye! Exiting now.....");
			}
			else if(option > 7 || option < 0)//Value entered is outside of range.
			{
				System.out.println("Invalid Option Selection, please enter an integer value between 1 - 7");
			}
			
			
		} while (option !=7);
		scanner.close();
	}
	
	public class MenuPrinter
	{
		/**
		 * <p>This method is invoked after the user has entered a valid file name and the array has been populated </p>
		 * 
		 * This function presents the user with the menu that they can choose from in order to determine the type of sorting
		 * action they wish to perform on the country array. the value of recordCount from main is passed here to ensure and indicate
		 * that all 128 countries has been accounted for as similarly demonstrated on the Project1 pdf
		 * 
		 * 
		 * @param recordCount - the variable holding the number of countries stored in the array
		 */
		public static void menu(int recordCount)
		{
			System.out.println("\nNumber of records read: " + recordCount);
			System.out.println("\nPlease Select an option between 1 - 7\n"+
								"1 - Print Country Report \n"+
								"2 - Sort Countries by name \n"+
								"3 - Sort Countries by Happiness Index \n"+
								"4 - Sort Countries by GDPPC \n"+
								"5 - Find/Search for Country \n"+
								"6 - Print Kendall's Tau Calculations \n"+
								"7 - Exit Program\n\n");
			
		}
	}
	
	public class Option1
	{
		/**
		 * <p><b>This method is invoked upon the user selecting Option 1 in the user menu.</b></p>
		 * 
		 * This function prints the contents of country array one by one, it uses a simple for loop and a counter[i]
		 * that starts at the beginning of the array, prints the data at the location of the index counter, and increases by 1 index
		 * and repeats the same process until the end of the array is reached.
		 * <p>
		 * each element of the array is printed using the printCountryObj located in the Country class. If this option is selected first
		 * before any sorting algorithm, it will print the data from the csv file line by line in the order in which it appears from the csv
		 * file. If the array is sorted in any manner, then the array is displayed based on how it is sorted.
		 * <p>
		 * @param country  The array containing the data parsed from countries1.csv 
		 */
		public static void printCountry(Country[] country)
		{
			System.out.println("NAME                                     Capital                                GDPPC       APC               Happiness Index");
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------");
			
			for(int i = 0; i < country.length; i++)
			{
				country[i].printCountryObj();
			}
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------");
		}
	}
	
	public class Option2
	{
		/**
		 * <p>
		 * <b>This method is invoked upon the user selecting option 2 in the user menu.</b>
		 * </p>
		 * 
		 * <p>
		 * This function is responsible for sorting the country array using insertion sort.
		 * Insertion sort works by utilizing 2 walkers, inner and outer, with outer starting at index 1.
		 * until the outer walker reaches the end of the array, for each iteration, it stores the country object that its at onto
		 * a temporary variable to use for comparison as it traverses the array. the temp variable is then used in the while loop to
		 * determine the right position for temp. once it does, it shifts the elements of the array to the right and continues until
		 * inner continues to iterate downwards until it is < 0. at this point, the array is sorted based on name.
		 * </p>
		 * the comparison between the country names are done using compareTo, which returns a positive, negative, or a 0 based on
		 * lexicographical comparisons.
		 * if compareTo returns a negative, it implies that the element in inner comes before the element in temp.
		 * however if its positive, this means that inner comes after temp. 
		 * <p>
		 * <b>Reference:</b> Chapter 3 Part 2, Insertion sort, Slide 14
		 * </p>
		 * @param country the array containing the data from the csv file that will be used for the sorting (insertion sort)
		 */
		public static void sortName(Country[] country)
		{
			int inner;
			int outer = 1;
			while(outer < country.length)
			{
				Country temp = country[outer];
				inner = outer - 1;
				//if the country at inner comes after the country in temp, shift to the right
				while(inner >= 0 && country[inner].getName().compareTo(temp.getName()) > 0)
				{
					country[inner + 1] = country[inner];
					inner--;
				}
				country[inner + 1] = temp;
				outer++;
			}
		}
	}
	
	
	public class Option3
	{
		/**<p>
		 * <b>This method is invoked upon the user selecting option 3 in the user menu.</b>
		 * </p>
		 * <p> 
		 * this function is responsible for sorting the array based on the Happiness Index using selection sort in ascending order.
		 * this selection sort works by iterating and looking for the lowest happiness index value starting from the first element of the array and searching for the smallest
		 * happiness index from the unsorted part of the array.
		 * the smallest known value in which the index is stored in the variable "lowest". when the inner loop iteration completes, then the value known in "lowest" is compared
		 * against the value in "outer". if they are different, ie lowest != outer, then a swap is performed in order to move the smallest element in the right position. However if
		 * the lowest is the same as outer, then this means that the element is in the correct position and no swaps are needed.
		 * </p>
		 * 
		 * <b>Reference:</b> Chapter 3 part 1, Selection sort, Slide 26
		 * 
		 * <p>
		 * @param country the array containing the data from the csv file that will be used for the sorting (selection sort)
		 */
		public static void sortHappiness(Country[] country)
		{
			
			for(int outer = 0; outer < country.length - 1; outer++)
			{
				int lowest = outer;
				for(int inner = outer + 1; inner < country.length; inner++)
				{
					//if country at inner is < country at lowest, inner becomes the new value for lowest.
					if(country[inner].getHapIndex() < country[lowest].getHapIndex())
					{
						lowest = inner;
					}
				}
				//if lowest = outer, no swaps are needed, but if lowest != outer, a swap is needed
				if(lowest != outer)
				{
					Country temp = country[lowest];
					country[lowest] = country[outer];
					country[outer] = temp;
				}
			}	
		}
	}
	
	public class Option4
	{
		/**
		 * <p>
		 * <b>This method is invoked upon the user selecting Option 4 in the user menu</b>
		 * </p>
		 * The function sorts the array based on their GDPPC value in ascending order using bubble sort.
		 * in order to sort the array correctly, we must consider that the csv file contains GDP values per
		 * country and NOT GDPPC. Therefore we must compare the country based on this measure and not GDP alone.
		 * to do so we have to take the GDP value of one country and divide it against the country's population and
		 * use the result value as our measure of comparison to use against the other countries.
		 * <p>
		 * Bubble sort works by iteratively comparing elements that are next to each other in the array. It starts
		 * from the end of the array compares the last element with the element before it to see if its GDPPC
		 * value is less than the GDPPC value of the last element. if the last element is less, then the two
		 * swap places and repeatedly does each iteration until the smallest GDPPC value essentially "bubbles up" to the top.
		 * This repeats until no swaps can be made, implying that the largest values are now at the end of the array
		 * and the smallest are at the beginning.
		 * <p>
		 * <b> GDPPC = GDP / Population </b>
		 * <p>
		 * <b>Reference:</b> Chapter 3, Part 1, Slide 12
		 * <p>
		 * @param country the array containing the CSV file that will be used for sorting (bubble sort)
		 */
		public static void sortGDP(Country[] country)
		{
			for(int outer = 0; outer < country.length - 1; outer++)
			{
				for(int inner = country.length - 1; inner > outer; inner--)
				{
					//perform arithmetic with get so that GDPPC is used to compare rather than GDP alone
					double GDPInner = country[inner].getGDP() / country[inner].getPop();
					double GDPInner2 = country[inner - 1].getGDP() / country[inner - 1].getPop();
					
					//if less, then swap
					if(GDPInner < GDPInner2)
					{
						Country temp = country[inner];
						country[inner] = country[inner - 1];
						country[inner - 1] = temp;
					}
				}
			}
		}
	}
	
	
	
	public class Option5
	{
		/**
		 * <p>
		 * <b>This method is invoked upon the user selecting Option 5 in the user menu.</b>
		 * </p>
		 * the find method prompts and allows the user to search for a country based on its name that is stored in the
		 * country array. this search method will either use binary or sequential search depending on the
		 * current state of the array upon selection. If the user selects this option first, or if the user sorts
		 * the array based on metrics aside from name, then the array is considered unsorted and sequential search
		 * is used. However if the array is sorted by name before selecting this option, then Binary search will be used instead.
		 * <p>
		 * For Binary search, which is used when the list is assumed to be sorted, we declare our bounds from the start of the array and at the end. 
		 * Once this is done, we then use a while loop that will continue as long as the lower bound
		 * is less than or equal to the upper bound. then by using the lower and upper bound , we can
		 * determine the middle point between the two boundaries. once this is done, it then compares
		 * the country name at the middle point against the provided country name. If the middle point
		 * is the country we're looking for, then we can display the information of the country since it is found
		 * if the country is not what we're looking for, then we can rely on compareTo to determine if the country 
		 * we're looking for is in the lower or upper half. if the lexicographic value of the mid point is greater
		 * than the value of cName, then this means our target is in the lower half and the upper boundry 
		 * is then moved to mid - 1. however if the value of mid is less than cName, then this means our target is in the upper half , then the 
		 * lower boundary is moved to mid + 1 instead. 
		 * </p>
		 * the comparison between the country names are done using compareTo, 
		 * which returns a positive, negative, or a 0 based on lexicographical comparisons similarly as to
		 * how we used it in Option 2 (insertion sort)
		 * <p>
		 * 
		 * For sequential search, which is used if the array is unsorted, preventing us from being able to compare the names,
		 * we just start from the beginning of the array and continue towards the end until the name of the country we're 
		 * looking for is found. If the country is still not found once the counter reaches the array, then the search
		 * is unsuccessful and lets the user know that the country was not found.
		 * <p>
		 * 
		 * <b>Reference:</b> Chapter 2, Binary Search, Slide 26, Sequential Search, Slide 30
		 * 
		 * @param country - The array containing the data parsed from countries1.csv to use for binary/sequential search
		 * @param sorted - The variable containing a boolean value to determine if we should use Binary or Sequential search
		 * on the array.
		 */
		public static void find(Country[] country, boolean sorted)
		{
			//ask the user for the name of the country to search for
			Scanner scanner = new Scanner(System.in);
			System.out.println("Please enter the name of a country to search for");
			String cName = scanner.nextLine();//variable for storing input name
			boolean found = false;
			
			if(sorted == true)//if the array is sorted by name, we use binary search
			{
				System.out.print("Searching for: " + cName + " Using Binary Search (Sorted)\n");
				int lowerBound = 0;
				int upperBound = country.length - 1;
				int mid;
				
				while(lowerBound <= upperBound)
				{
					mid = (lowerBound + upperBound) / 2;
					//compare the name retrieved at the given index [mid] with the provided country name (cName)
					if(country[mid].getName().equals(cName))
					{
						//if found, print country info
						System.out.println("--------------------------------------------\n");
						System.out.printf("Name:      %-40s%n" , country[mid].getName());
						System.out.printf("Capital:   %-35s%n" , country[mid].getCapital());
						System.out.printf("GDPPC:     %.3f%n", country[mid].getGDP() / country[mid].getPop());
						System.out.printf("APC:       %.6f%n", country[mid].getArea() / country[mid].getPop());
						System.out.printf("Happiness: %.3f%n", country[mid].getHapIndex());
						System.out.println("\n--------------------------------------------");
						found = true;
						return;
					}
					else if(country[mid].getName().compareTo(cName) > 0)
					{
						upperBound = mid - 1; //lower half
					}
					else
					{
						lowerBound = mid + 1; //upper half
					}
				}
				System.out.print(cName + " Not Found");
			}
			
			else //else if the array is unsorted, or is sorted by a different measure other than name, use sequential search.
			{
				System.out.print("Searching for: " + cName + " Using Sequential Search (Unsorted)\n");
				int j = 0;
				while(j < country.length)
				{
					if(country[j].getName().equals(cName)) //Country found, print the details
					{
						System.out.println("--------------------------------------------\n");
						System.out.printf("Name:      %-40s%n" , country[j].getName());
						System.out.printf("Capital:   %-35s%n" , country[j].getCapital());
						System.out.printf("GDPPC:     %.3f%n", country[j].getGDP() / country[j].getPop());
						System.out.printf("APC:       %.6f%n", country[j].getArea() / country[j].getPop());
						System.out.printf("Happiness: %.3f%n", country[j].getHapIndex());
						System.out.println("\n--------------------------------------------");
						found = true;
						break;
					}
					j++; //keep going up the array till found
				}
				if(found == false)
				{
					System.out.print(cName + " Not Found");
				}
			}
		}
	}
	
	public class BonusSort
	{
		/**
		 * <p>
		 * <b>This is an extra sorting algorithm that closely mimics bubble sort to sort the array based on Area per Capita.</b>
		 * </p>
		 * <p>
		 * This method is not invoked directly from the user menu, but instead is a method used for option 6 to sort the APC array.
		 * the method follows the same concept used for bubble sort and sorts the array passed to it ascendingly, bubbling the smallest value
		 * at the start of the array and the largest at the end.
		 * </p>
		 * <p>
		 * It is sorted based on Area per Capita and not area alone, this is done by 
		 * calculating the area / population, storing the value in APCInner, and comparing the value against APCInner2 to determine if the first element
		 * is smaller than the second element. if it is, then a swap is performed to sort the array in ascending order.
		 * </p>
		 * 
		 * <b>Reference:</b> Chapter 3, Part 1, Slide 12
		 * @param country - The array containing the data parsed from countries1.csv to use for sorting
		 * 
		 */
		public static void sortAPC(Country[] country)
		{
			for(int outer = 0; outer < country.length - 1; outer++)
			{
				for(int inner = country.length - 1; inner > outer; inner--)
				{
					//perform arithmatic so that APC is used to compare rather than Area alone
					double APCInner = country[inner].getArea() / country[inner].getPop();
					double APCInner2 = country[inner - 1].getArea() / country[inner - 1].getPop();
					
					if(APCInner < APCInner2)
					{
						Country temp = country[inner];
						country[inner] = country[inner - 1];
						country[inner - 1] = temp;
					}
				}
			}
		}
	}
	
	public class Option6
	{
		/**
		 * 
		 * <p>
		 * <b>This method is invoked upon the user selecting Option 6 in the user menu.</b>
		 * </p>
		 * the method performs kendall tau's correlation between the happiness index vs the GDPPC and the happiness index vs the Area Per Capita.
		 * this is done by creating two new arrays that are a copy of the original array so that we may sort them separately based on the metric 
		 * we aim to calculate for. in this case, it is the GDPPC and APC. Since sorting by GDPPC is an operation already performed in Option 4, 
		 * we simply pass sortedGDP onto the option to sort the GDPPC in ascending order using bubble sort. as for the sorting of APC, we call a
		 * bonus sorting algorithm that uses the same bubble sort method used for GDPPC, but instead measures the APC instead and sorts the array in 
		 * ascending order. 
		 * <p>
		 * Once we have the sorted arrays, we then declare 2 counters each for GDPPC and APC to store the agreement pairs and disagreement pairs to use
		 * for calculations later on. the agreement/disagreement counter for GDPPC is aGDPPC and dGDPPC, whilst the agreement/disagreement pair for APC
		 * is aAPC and dAPC. to check for all unique pairs in the array, we rely on a nested for-for loop that has 2 walkers named as r1 and r2, with r2 always
		 * being 1 index ahead of r1 in order to only check for unique country pairs. for each country pair r1 and r2 lands on, the happiness index value of r1 is then stored
		 * onto hapIndexR1 and the happiness index value of the country r2 is on is then stored onto hapIndexR2. The same is done for GDP in this iteration as well, with the 
		 * value being stored in gdppcR1 being the country's GDP per capita value instead of GDP alone. The same calculation and store logic is used as well for gdppcR2.
		 * once we have a value for hapIndexR1 vs hapIndexR2, and a value for gdppcR1 vs gdppcR2, we then use compareTo to check the happiness ranking and GDPPC ranking
		 * of the current country r1 and r2 is on. for the happiness index, if the value of r1 is < r2, then a negative value is stored in hapIndexR1vsR2. if r1 is > r2,
		 * then a positive value is stored instead. if they are equal, then a value of 0 is stored. this same comparison is done for GDP as well. Once a value is stored for
		 * hapIndexR1vsR2 and gdppcR1vsR2, then the method for determining agreement/disagreement is now set in place. Since the values stored in hapIndexR1vsR2 and gdppcR1vsR2
		 * will either be -1, 1, or a 0, we then just multiply them against one another to check if they agree/disagree. if the value stored in hapIndexR1vsR2 
		 * are the same as the value stored in gdppcR1vsR2. ie, both are positive, or both are negative, then  multiplying them against one another will always result in a value > 0
		 * but if they have opposing values, such as hapIndexR1vsR2 has a negative value and gdppcR1vsR2 has a positive or vice versa, then when they are multiplied against one another
		 * a negative number will be the result implying that the two pairs disagree between the happiness index and the GDPPC.
		 * </p>
		 * <p>
		 * By comparing the values of hapIndexR1vsR2 and gdppcR1vsR2, we still follow the core logic behind properly calculating kendall Tau's Correlation:
		 * <p>
		 * <ol>
		 * <li>If x1 < x2 & y1 < y2 OR x2 < x1 & y2 < y1, <b>then the pair are concordant (pair agrees). </b>
		 * <li>else if x1 < x2 & y1 > y2 OR x2 < x1 & y2 > y1, <b>then the pair is discordant(pair disagrees).</b>
		 * </ol>
		 * <p>
		 * This process continues until all unique possible pairs
		 * have been compared, continuously iterating the agreement/disagreement counters. The same process is performed against happiness index and APC as well. when all unique pairs 
		 * are checked for both measures, we then peform the kendall Tau correlation calculation using the formula <b>( A(R1, R2) - D(R1, R2) ) / ( n(n-1)) / 2 )</b>. using the agreement/disagreement
		 * counters to act as <b>A(R1, R2) and D(R1,R2)</b>. when the calculation is performed between happiness index vs GDPPC and happiness index vs APC, the result is then displayed to the
		 * user.
		 * </p>
		 * 
		 * <p>
		 * To ensure that all unique pairs have been scanned, the total number of pairs when adding the agree/disagree counter should equal to 8128 pairs. 
		 * </p>
		 * 
		 * <p>
		 * This method however only considers whether or not a pair is at an agreement/disagreement, it doesn't consider cases where it results in a tie. However as of 09/13/2023,
		 * a modified version of countries1.csv has been issued to use with this project that removes the possibilities of ties between the Happiness Index vs GDPPC and Happiness Index
		 * vs APC.
		 * </p>
		 * 
		 * <p>
		 * <b>Reference:</b> 
		 * <ol>
		 * <li>Project 1 PDF - Kendall Tau Description
		 * <li>Kendalls Correlation (Commons.apache) - 
		 * https://commons.apache.org/proper/commons-math/javadocs/api-3.6.1/org/apache/commons/math3/stat/correlation/KendallsCorrelation.html
		 * <ol>
		 * </p>
		 */
		public static void kendallTau(Country[] country)
		{
			//create new arrays for the fields being measured.
			Country[] sortedGDP = new Country[country.length];
			Country[] sortedAPC = new Country[country.length];
			
			//Simple loop to copy the contents of the original array onto the newly created arrays
			for(int i = 0; i < country.length; i++)
			{
				sortedGDP[i] = country[i];
				sortedAPC[i] = country[i];
			}
			
			//sort the newly created arrays
			//Since we've already have sort function based on GDP that uses bubble sort to sort ascendingly, we can call Option4.
			//Since we also have to sort based on Area Per Capita, we call our extra sorting algorithm BonusSort, to sort APC ascendingly.
			Option4.sortGDP(sortedGDP);
			BonusSort.sortAPC(sortedAPC);
			
			//Create the variable that will hold the count value for agreements/disagreements (2 for each kendall tau value to calculate)
			//A(R1, R2) and D(R1 and R2) for GDPPC and APC
			double aGDPPC = 0;
			double dGDPPC = 0;
			
			//Agree/Disagree Counter for APC
			double aAPC = 0;
			double dAPC = 0;
			
			
			//in this nested for loop, [r1] will act as R1, and [r2] will act as R2
			//loop and scan each element of the array using nested for for loop
			for(int r1 = 0; r1 < country.length; r1++)
			{
				for(int r2 = r1 + 1; r2 < country.length; r2++)
				{
					Double hapIndexR1 = sortedGDP[r1].getHapIndex();
					Double hapIndexR2 = sortedGDP[r2].getHapIndex();
					int hapIndexR1vsR2 = hapIndexR1.compareTo(hapIndexR2);
					
					Double gdppcR1 = sortedGDP[r1].getGDP() / sortedGDP[r1].getPop();
					Double gpppcR2 = sortedGDP[r2].getGDP() / sortedGDP[r2].getPop();
					int gdppcR1vsR2 = gdppcR1.compareTo(gpppcR2);
					
					//if hapIndexR1vsR2 and gdppcR1vsR2 have the same value, 1, or -1, the pair agrees (x1 < x2 & y1 < y2 OR x1 > x2 & y1 > y2)
					if(hapIndexR1vsR2 * gdppcR1vsR2 > 0)
					{
						aGDPPC++;
					}
					// else if the two have opposite values from each other, the pair disagrees.(x1 < x2 & y1 > y2 OR x1 > x2 & y1 < y2)
					else if(hapIndexR1vsR2 * gdppcR1vsR2 < 0)
					{
						dGDPPC++;
					}
					
				}
			}
			//repeat the same process for Happiness Index vs APC
			for(int r1 = 0; r1 < country.length; r1++)
			{
				for(int r2 = r1 + 1; r2 < country.length; r2++)
				{
					Double hapIndexR1APC = sortedAPC[r1].getHapIndex();
					Double hapIndexR2APC = sortedAPC[r2].getHapIndex();
					int hapIndexR1vsR2APC = hapIndexR1APC.compareTo(hapIndexR2APC);
					
					Double apcR1 = sortedAPC[r1].getArea() / sortedAPC[r1].getPop();
					Double apcR2 = sortedAPC[r2].getArea() / sortedAPC[r2].getPop();
					int apcR1vsR2 = apcR1.compareTo(apcR2);
					
					if(hapIndexR1vsR2APC * apcR1vsR2 > 0)
					{
						aAPC++;
					}
					else if(hapIndexR1vsR2APC * apcR1vsR2 < 0)
					{
						dAPC++;
					}
				}
			}
			//calculate the collected agreement/disagreement pairs
			// Formula: ( A(R1, R2) - D(R1, R2) ) / ( n(n-1)) / 2 )
			// A(R1, R2) = aGDPPC and aAPC
			// D(R1, R2) = dGDPPC and dAPC
			double kenTauGDPPC = (aGDPPC - dGDPPC) / (country.length * (country.length - 1) / 2);
			double kenTauAPC = (aAPC - dAPC) / (country.length * (country.length - 1) / 2);
			double gdppcPair = aGDPPC + dGDPPC;
			double apcPair = aAPC + dAPC;
			
			//test - for 128 countries, a total of 8128 unique pairs is needed!
			System.out.print("GDP agreement pairs: " + aGDPPC + "GDP Disagreement Pairs: " + dGDPPC + "\n");
			System.out.print("Total pairs for GDPPC: " +gdppcPair+"\n");
			System.out.print("APC agreement pairs: " + aAPC + "APC Disagreement Pairs: " + dAPC + "\n");
			System.out.print("Total pairs for APC: " +apcPair+"\n");
			
			System.out.println("--------------------------------------------");
			System.out.println("               - GDPPC -        - AreaPC -  ");
			System.out.printf("Happiness Index: %.4f           %.4f     \n",kenTauGDPPC,kenTauAPC );
			System.out.println("--------------------------------------------");
		}
	}
	
	

}

