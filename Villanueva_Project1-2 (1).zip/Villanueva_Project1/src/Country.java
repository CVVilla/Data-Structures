/**
 * @author Calvin Villanueva
 * @version 09/15/2023
 * <p>
 * This is the country class for Project 1
 * 
 * The country class is predominantly in charge of retrieving data from the array to use for comparison and sorting.
 * The country class also contains the method for printing the country object(s) from the array as instructed on the project 1 pdf. 
 * </p>
 * 
 * <p>
 * <b> Project 1 uses the newly updated "Countries1.csv" uploaded on 09/13/2023 to eliminate the possibilities of ties during the Kendall Tau calculations.</b>
 * </p>
 * 
 * <b>Reference(s): </b>
 * <ol>
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing
 * 	<li><b>Insertion Sort</b> - Ch.3 - part 2 (Slide 6)
 * 	<li><b>Selection Sort</b> - Ch.3 - part 1 (Slide 26)
 * 	<li><b>Bubble Sort</b> - Ch.3 - part 1 (Slide 12)
 * 	<li><b>Binary Search</b> - Ch.2 (slide 26)
 * 	<li><b>Sequential Search</b> - Ch.2 (slide 30)
 * 	<li><b>Kendall Tau</b> - Project 1 PDF 
 * <ol>
 * 
 */

public class Country 
{
	/**
	 * Constructor for making a country object with the specified attribute fields
	 * @param name - Country Name
	 * @param capital - Country Capital
	 * @param pop - Country Population
	 * @param GDP - Country GDP
	 * @param area - Country Area
	 * @param hapIndex - Country Happiness Index
	 */
	private String name;
	private String capital;
	public double pop;
	public double GDP;
	public double area;
	public double hapIndex;
	
	
	/**
	 * This method is invoked upon the user selecting the first option in the user menu in the 
	 * project1 class. In order to not edit the contents of the array and match the output of the examples
	 * the project1.pdf provides, we calculate the value of GDPPC and APC of each country being printed and
	 * display those values to the user instead of just the GDP and Area value. when option 1 is selected, 
	 * option 1 uses a simple for loop to print the element at each index until the end of the array is reached.  
	 * This method is invoked at the same time as the header to closely match the format of the example outputs. 
	 * 
	 */
	public void printCountryObj()
	{
		
		System.out.printf("%-40s %-35s %10.3f %10.6f %18.3f%n", name, capital, GDP / pop, area / pop, hapIndex);
	}
	
	public Country(String name, String capital, double pop, double GDP, double area, double hapIndex)
	{
		this.capital = capital;
		this.name = name;
		this.GDP = GDP;
		this.pop = pop;
		this.area = area;
		this.hapIndex = hapIndex;
		
	}
	
	/**
	 * 
	 * @return - Country Name - Get the current country's Name
	 */
	//Create the GETs and SETs for each of the fields. GETs first
	public String getName()
	{
		return name;
	}
	
	
	/**
	 * 
	 * @param name - sets a name for country name (not used)
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	
	
	/**
	 * 
	 * @return - Country Capital - Get the current country's Capital Name
	 */
	public String getCapital()
	{
		return capital;
	}
	
	
	/**
	 * 
	 * @param capital - set a name for country capital (not used)
	 */
	public void setCapital(String capital)
	{
		this.capital = capital;
	}
	
	
	/**
	 * 
	 * @return - Country Population - Get the current country's population count
	 */
	public double getPop()
	{
		return pop;
	}
	
	
	/**
	 * 
	 * @param pop - set a country's population value (not used)
	 */
	public void setPop(double pop)
	{
		this.pop = pop;
	}
	
	
	/**
	 * 
	 * @return - Country GDP - Get the current country's GDP value
	 */
	public double getGDP()
	{
		return GDP;
	}
	
	
	/**
	 * 
	 * @param GDP - sets a country's GDP value (not used)
	 */
	public void setGDP(double GDP)
	{
		this.GDP = GDP;
	}
	
	
	/**
	 * 
	 * @return - Country Area - Get the current country's Area Value
	 */
	public double getArea()
	{
		return area;
	}
	
	
	/**
	 * 
	 * @param area - sets a country's Area value (not used)
	 */
	public void setArea(double area)
	{
		this.area = area;
	}
	
	
	
	/**
	 * 
	 * @return Country Happiness Index - Get the current country's Happiness Index Value
	 */
	public double getHapIndex()
	{
		return hapIndex;
	}
	
	
	/**
	 * 
	 * @param hapIndex - sets a country's Happiness Index Value (not used)
	 */
	public void setHapIndex(double hapIndex)
	{
		this.hapIndex = hapIndex;
	}
	
	
}
