/**
 * @author Calvin Villanueva
 * @version 11/17/2023
 * <p>
 * This is the Node class for Project4.java. The Node class essentially acts as the backbone of our binary search tree and also 
 * serves as a replacement for our original Country.java class we've previously used in our other projects. Since in this project we only
 * consider 2 columns of data rather than the entire record (country name and happiness index) we will only need to parse the two fields 
 * whenever we are first populating the Binary Search Tree for the first time.  The Node class is essential as it acts as the building
 * blocks for our tree, with each nodes representing our data.
 * </p>
 * <p>
 * For this class, we initialize the two previously mentioned data fields (country name and happiness index) along with the pointers
 * to represent the left child and the right child node to maintain our BST structure/linkage. When a node is created during insert, 
 * each node will contain the country name and the happiness index value parsed from the csv as well as the left and child node being
 * initiated as null until they are placed in the correct position on the BST.
 * 
 * Additionally, the method to print the details of a node is also done here in order to meet the project requirement. 
 * </p>
 * 
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Binary Trees  - Textbook </b> - Chapter 8 Binary Trees, Page 406 - 415, "The tree.java"
 * 		- class Node
 * 		- class Tree
 * 		- public Node find
 * 		- public void insert
 * 		- public boolean delete
 * 		- private Node getSuccessor
 * 		- public void traverse(Preorder, postOrder and Inorder)
 *  <li><b>Stacks and Queues  - Textbook </b> - Chapter 4 Stacks and Queues, Page 147, "priorityQ.java"
 *  	- public void insert
 *  <li><b>Binary Search Tree Part 1 </b> - Chapter 8 Part 1 regarding node class, find, insert, and traversal.
 * 	<li><b>Binary Search Tree Part 2</b> - Chapter 8 Part 2 regarding deletion method. 
 *  <li><b>Project 1</b> - Regarding compareTo for name comparison to use for insert, find and delete.
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing  
 * <ol>
 * </p> 
 */
class Node 
{
	public String countryName;
	public double hapIndex;
	Node leftChild;
	Node rightChild;
	
	public Node(String countryN, double hIndex)
	{
		countryName = countryN;
		hapIndex = hIndex;
		leftChild = null;
		rightChild = null;
	}
	
	public void printNode()
	{
		System.out.printf("%-40s %-15.3f%n", countryName, hapIndex);
	}
}
