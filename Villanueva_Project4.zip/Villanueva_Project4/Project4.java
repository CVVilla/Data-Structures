import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * @author Calvin Villanueva
 * @version 11/17/2023
 * 
 * <p>
 * This is the Project 4 class containing the main driver for our program. The main method is largely unchanged from the previous project with
 * exception to slight modifications made with the parsing method, initialization of the Binary Search Tree and the menu options. Main is 
 * primarily in charge of 3 main components when the program is executed. First, it prompts the user for the CSV file to open. Second, when the 
 * file name given is valid, the while fist while loop inserts the elements of the csv onto our Binary Search Tree, but only accounting for the country
 * name and the happiness index instead of the whole record. and third, it presents the user with a repeating menu that allows them to perform operations
 * against our BST until prompted to quit. 
 * </p>
 * 
 * <p>
 * The menu contains error catches in the event the user enters values that are outside the given range (1-9) and or if the value entered is not numeric.
 * additionally, methods that invoke the user to enter country names such as insert, delete and search allows the user to enter the country names without
 * having to worry about case-sensitivity, although it is worth noting that this logic is incorporated in the BinarySearchTree.java. Lastly, additional error
 * checks were incorporated onto option 7 and 8 as well using a similar approach used in the menu. This was implemented to prevent the program from terminating due
 * to an error such as a user entering a letter instead of a numeric value for c to use as the array size. 
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Binary Trees  - Textbook </b> - Chapter 8 Binary Trees, Page 406 - 415, "The tree.java"
 * 		- class Node
 * 		- class Tree
 * 		- public Node find
 * 		- public void insert
 * 		- public boolean delete
 * 		- private Node getSuccessor
 * 		- public void traverse(Preorder, postOrder and Inorder)
 *  <li><b>Stacks and Queues  - Textbook </b> - Chapter 4 Stacks and Queues, Page 147, "priorityQ.java"
 *  	- public void insert
 *  <li><b>Binary Search Tree Part 1 </b> - Chapter 8 Part 1 regarding node class, find, insert, and traversal.
 * 	<li><b>Binary Search Tree Part 2</b> - Chapter 8 Part 2 regarding deletion method. 
 *  <li><b>Project 1</b> - Regarding compareTo for name comparison to use for insert, find and delete.
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing  
 * <ol>
 * </p>
 */

public class Project4 
{	
	/**
	 * <b>This is the main function of project 4</b>
	 * <p>
	 * First, it prompts the user to enter a file name to locate in order to parse the entries onto the BST. For this project, it is named as "Countries4.csv".
	 * </p>
	 * <p>
	 * Once the correct filename has been entered, the first line containing the header in the csv is skipped and each entry / row is parsed onto the BST, with each row only capturing
	 * the country name and the happiness index of the given country and inserting them onto the BST based on their name value lexicographically.
	 * </p>
	 * <p>
	 * Then, the user is then presented with a repeating menu until the user selects the 9th menu option to quit the program. From this menu, the user can view and manipulate the contents
	 * of the BST by choosing one of the menu options. When the user selects options such as insert, delete, or find, the program prompts the user for a country name in order to fulfill the operation.
	 * If the operation is insert, then an accompanying happiness index value for the new country to be inserted is also required. If the user selects 7th or 8th menu option, the program then prompts
	 * the user to provide a numeric value to use for c. If the user enters a value greater than the number of nodes in the BST (128), then all the nodes are placed inside an array and is printed 
	 * ascendingly / descendingly based on the option selected. 
	 * </p>
	 * 
	 * 
	 * <p>
	 * The main function contains error handling when it comes to the user inputing an invalid file name and an invalid menu choice selection
	 * The main function also has the necessary checks needed to see if the values entered for the 7th and 8th menu option is of numeric type and is not
	 * a negative value to prevent the program from running to an error. 
	 * </p>
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		
	
		BinarySearchTree bst = new BinarySearchTree();
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the name of the file to open (Countries4.csv) ");
		String fileName = input.next();
		System.out.println("Opening File: " + fileName);
		Scanner file = null;

		
		try
		{
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)//catch for invalud input
		{
			System.out.println("Error the file name entered cannot be found");
			System.exit(1);
			input.close();
		}
		
		file.nextLine();//skip the header!
		file.useDelimiter(",|\n");
		
		while(file.hasNext())
		{
			String name = file.next();
			file.next();
			file.nextDouble();
			file.nextDouble();
			file.nextDouble();
			double hapIndex = Double.parseDouble(file.next());

			bst.insert(name, hapIndex);
			
			
		}

		file.close();//close scanner
		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		
		do
		{
			//Prompt the user menu
			MenuPrinter.menu();
			
			try
			{
				option = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Option Selected: " + option);
			}
			catch(InputMismatchException e)//catch input that may not be digit
			{
				System.out.println("Invalid Option Selection, please enter a numeric value");
				scanner.nextLine();
				continue;
			}
			
			if(option == 1) //print InOrder
			{
				displayHeader();
				bst.printInorder();
				
			}
			
			if(option == 2) //print preOrder
			{
				displayHeader();
				bst.printPreOrder();
				
			}
			
			if(option == 3) //print postOrder
			{
				displayHeader();
				bst.printPostOrder();
				
			}
			
			if(option == 4) //Insert Country
			{
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to add:");
				String cName = inputScanner.nextLine();
				
				System.out.print("Enter the Happiness Index value for: " + cName + " ");
				Double hapIndex = inputScanner.nextDouble();
				
				bst.insert(cName, hapIndex);
				System.out.println("Country: " + cName + " Added with the happiness index value of: " + hapIndex);
			}
			
			if(option == 5) //Delete Country
			{
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to delete:");
				String cNameToDel = inputScanner.nextLine();
				
				bst.delete(cNameToDel);
			}
			
			if(option == 6) // find/print country path & HapIndex 
			{
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to search for:");
				String cName = inputScanner.nextLine();
				
				double hapIndex = bst.find(cName);
				
				if(hapIndex != -1)
				{
					System.out.println("The happiness Index of " + cName + " is: " + hapIndex);
				}
				else
				{
					System.out.println("Search failed, country not found!");
				}
			}
			
			if(option == 7) //Retrieve c number of bottom countries
			{
				int c = 0;
				Scanner inputScanner = new Scanner(System.in);
				while(true)
				{
					System.out.print("Enter the number of countries to retrieve: ");
					try
					{
						c = inputScanner.nextInt();
						if(c <= 0)
						{
							System.out.println("Please enter a value greater than 0.");
						}
						else
							break;
					}
					catch(InputMismatchException e)
					{
						System.out.println("Invalid Value entered. Value must be numeric, please enter a numeric value");
						inputScanner.next();
					}
				}
				displayHeader();
				bst.printBottomCountries(c);
			}
			
			if(option == 8) // retrieve c number of top countries
			{
				int c = 0;
				Scanner inputScanner = new Scanner(System.in);
				while(true)
				{
					System.out.print("Enter the number of countries to retrieve: ");
					try
					{
						c = inputScanner.nextInt();
						if(c <= 0)
						{
							System.out.println("Please enter a value greater than 0.");
						}
						else
							break;
					}
					catch(InputMismatchException e)
					{
						System.out.println("Invalid Value entered. Value must be numeric, please enter a numeric value");
						inputScanner.next();
					}
				}
				displayHeader();
				bst.printTopCountries(c);
			}

			if(option == 9)//user selected the 7th menu option closing the program.
			{
				System.out.println("Thank you and goodbye! Exiting now.....");
			}
			if(option > 9 || option <= 0) //Out of bounds check
			{
				System.out.println("Invalid Option Selection, please enter an integer value between 1 - 9");
			}
			
		} while (option !=9);
		scanner.close();
		
	}
	
	public class MenuPrinter
	{
		public static void menu()
		{
			System.out.println("\n\nCOP3530 Project 4");
			System.out.println("Author: Calvin Villanueva (N01068487)");
			System.out.println("\nPlease Select an option between 1 - 9\n"+
								"1 - Print Tree In-Order \n"+
								"2 - Print Tree Pre-Order \n"+
								"3 - Print Tree Post-Order \n"+
								"4 - Insert a country with name and happiness index \n"+
								"5 - Delete country with a given name \n"+
								"6 - Search and Print a country and its path for a given name \n"+
								"7 - Print bottom countries regarding happiness \n"+
								"8 - Print top Countries regarding happiness \n"+
								"9 - Exit Program\n\n");		
		}
	}
	public static void displayHeader()
	{
		System.out.printf("%-40s %-15s%n", "Name", "Happiness Index");
		System.out.println("--------------------------------------------------------");
	}
}

