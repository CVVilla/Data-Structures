/**
 * @author Calvin Villanueva
 * @version 11/17/2023
 * 
 * <p>
 * This is the BinarySearchTree or BST for Project 4. The structure of this code is primarily derived from the example code shown and demonstrated on Chapter 8, starting on pg.406 - 415, named as "Tree.java".
 * In this example, the book show cases and demonstrate some of the standard functionalities of the methods typically included with a BST. The example shown provides a good starting point in which we've tailored to
 * fit the project requirements. Additionally, references to previous projects were used as well such as project 1 since it contained a method for sorting an array based on names, which was referenced in order to use
 * compareTo for our insertion, deletion, and find methods, As well as project 2 regarding insertion to a priorityQ array, which we've reused as a part of our get top/bottom countries method. 
 * </p>
 * 
 * <p>
 * When the program is compiled and a valid file name is given to the program, the first while loop in project 3 parses the elements from the CSV onto our BST, only accounting for details such as the country name and the happiness index.
 * The insertion method is used throughout this process and the BST is arranged and organized using the name values of each country. Once the BST is populated from the CSV entries, the repeating menu for interacting with the BST is then
 * presented to the user to manipulate the contents of the BST.
 * </p>
 * 
 * <p>
 * From the Menu, the user can choose to print the tree in either In order, preorder, or post order traversal, Insert a new country onto the BST, in which the user provides the Country Name and the Happiness Index Value of the given country,
 * Delete a country with a given name, and search for a country with a given name to print the path to reach that country. Additionally, the last 2 options in the menu allows the user to pull the top/bottom countries in terms of happiness index
 * by specifying the number of countries they wish to pull. alternatively, it also allows the user to essentially sort the BST in either ascending or descending order based on happiness index if the user enters a value greater than
 * the number of nodes found in the BST (128).
 * </p>
 * 
 * <p>
 * <b>Brief Description of the methods found in this class:</b>
 * </p>
 * 
 * <ol>
 * <li>1. Insert - Based off of the insert method from the example, the insert method inserts nodes onto the BST based on name values using compareToIgnoreCase. 
 * 
 * <li>2. Find - Based off of the find method from the example, the find method traverses the array in search of the name given by the user. For each node it visits, the name of the node is added into a string until it reaches
 * the target node, in which the string is then printed to show the path traversal took to reach the target node. 
 * 
 * <li>3. Delete - Based off of the delete method and getSuccessor method from the example, the delete method ensures a node deletion whilst still maintaining the order of the BST. It takes account of 4 possible scenarios that can
 * be met during deletion on a BST; When a node has no child, When a node has 1 child (left or right) and when a node has 2 child, in which getSuccessor is used to find the successor and reassign the child nodes of the node
 * to be deleted.
 * 
 * <li>4. printInOrder - Based off of the traverse method from the example, The method traverses the BST recursively following in order traversal rules (LNR) to print the contents of the BST. 
 * 
 * <li>5. printPreOrder - Based off of the traverse method from the example, The method traverses the BST recursively following pre order traversal rules (NLR) to print the contents of the BST.
 * 
 * <li>6. printPostOrder - Based off of the traverse method from the example, The method traverses the BST recursively following post order traversal rules (LRN) to print the contents of the BST.
 * 
 * <li>7. printBottomCountries - Based off of the traverse method for traversal (uses inOrder Traversal) and the priorityQ insert from project 2 for insertion of bottom countries onto an array with the size specified by the user. It traverses the BST
 * In search of the bottom c countries found in the BST and prints the result to the user in ascending order.
 * 
 * <li>8. printTopCountries - Based  off of the traverse method for traversal (uses inOrder traversal as well) and the priorityQ insert from project 2 for insertion of the top countries onto an array with the size specified by the
 * user. It traverses the BST in search of the top c countries found within the BST and prints the result in descending order to the user. 
 * </ol>
 * 
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Binary Trees  - Textbook </b> - Chapter 8 Binary Trees, Page 406 - 415, "The tree.java"
 * 		- class Node
 * 		- class Tree
 * 		- public Node find
 * 		- public void insert
 * 		- public boolean delete
 * 		- private Node getSuccessor
 * 		- public void traverse(Preorder, postOrder and Inorder)
 *  <li><b>Stacks and Queues  - Textbook </b> - Chapter 4 Stacks and Queues, Page 147, "priorityQ.java"
 *  	- public void insert
 *  <li><b>Binary Search Tree Part 1 </b> - Chapter 8 Part 1 regarding node class, find, insert, and traversal.
 * 	<li><b>Binary Search Tree Part 2</b> - Chapter 8 Part 2 regarding deletion method. 
 *  <li><b>Project 1</b> - Regarding compareTo for name comparison to use for insert, find and delete. 
 * <ol>
 * </p>
 */

public class BinarySearchTree 
{
	private Node root;
	//constructor to create empty tree
	public BinarySearchTree()
	{
		root = null;
	}
	/**
	 * <p>
	 * This is our insert method for our BST. It is mostly based off of the insert method demonstrated in pg.406 "tree.java".
	 * The example code was modified to insert countries onto our binary search tree based on their Country Names, instead of a 
	 * numeric value such as demonstrated in the example code. In this case, we rely on compareTo to utilize a similar logic in 
	 * project 1 where we sorted countries based on names, as compareTo allows us to compare the country names lexicographically to
	 * determine proper placement. the value returned by compareTo is our determining value that determines whether the new country
	 * to be inserted should go left or right. If compareTo returns a negative value (meeting the condition of nameValue < 0 ), then this indicates
	 * the country to be inserted should come before the country in current, making the new country the left child. else if the nameValue
	 * is a positive value ( > 0 ), then the country to be inserted should come after the country in current, making it the right child.
	 * </p>
	 * 
	 * <p>
	 * Additionally, the insert method has also been modified slightly to add an additional condition during insertion, which is when nameValue == 0, 
	 * which implies that the country name being inserted has came across a node with an exact name. In this case, since there are no duplicate countries
	 * with two different values for happiness index, we opted to simply informing the user that the node of the given name already exists within the BST
	 * and fail the operation. The use of compareToIgnoreCase was also implemented for this reason as the user may try to insert a country in all lowercase
	 * letters, in which a regular compareTo would not be able to identify that france = France which would allow insertion of a duplicate. 
	 * </p> 
	 *  
	 * @param countryName
	 * @param hapIndex
	 */
	public void insert(String countryName, double hapIndex)
	{
		Node newNode = new Node(countryName, hapIndex);
		newNode.countryName = countryName;
		newNode.hapIndex = hapIndex;
		if(root == null)
		{
			root = newNode;
		}
		else
		{
			Node current = root;
			Node parent;
			while (true)
			{
				int nameValue = countryName.compareToIgnoreCase(current.countryName);
				parent = current;
				if (nameValue < 0) //go left
				{
					current = current.leftChild;
					if(current == null)
					{
						parent.leftChild = newNode;
						return;
					}
				}
				else if(nameValue > 0)//go right
				{
					current = current.rightChild;
					if (current == null)
					{
						parent.rightChild = newNode;
						return;
					}
				}
				else if(nameValue == 0)
				{
					System.out.println("Warning! the country being added: " + countryName + " Is already in the Tree! Insertion failed due to duplicates.");
					return ;
				}
			}
		}
	}
	/**
	 * <p>
	 * The find method is the method invoked when the user selects the 6th menu option to search and print a country for its path on the BST. 
	 * It is largely based off of the find method found on the example code demonstrated on pg. 407 "tree.java". Since this method relies on
	 * comparing the given name by the user against the names of countries on our BST, we rely on using compareToIgnoreCase once again in order to match
	 * the key. In this method, we opted for compareToIgnoreCase primarily for ease of use so that the user doesn't need to worry about case sensitivity.
	 * additionally, we've expanded on the logic that determines whether to keep traversing left or right in search of the given key from the example code.
	 * as the method traverses the tree either left or right, for every node it visits, it adds the name of the country current lands on onto our 'Path' string.
	 * By doing so, the moment the key is found (which would break the while loop), we can add the destination node to the end of the path string and print the path string to emulate
	 * and visualize the path the method took in order to reach the destination key. When this path string is printed, it prints the first node it visits (root) all the
	 * way down to the node where the destination key is located. As specified, when the key given by the user has been found and the path to the node has been printed, 
	 * we return the happiness index value of the key so that we can print the value to the user. the return of the country's happiness index signifies a successful search
	 * where as If the search fails, then the method simply returns a -1 value in which is used to indicate to the user that the search has failed.  
	 * </p>
	 * 
	 * @param name
	 * @return The happiness index of the found country or -1 if the search has failed.
	 */
	public double find(String name)
	{
		Node current = root;
		String path = "\nPath taken to reach "+ name + ":\n";
		
		while(!current.countryName.equalsIgnoreCase(name)) 
		{
			int key = name.compareToIgnoreCase(current.countryName);
			if(key < 0) //go left
			{
				path += current.countryName + " -> ";
				current = current.leftChild;
			}
			else //go right
			{
				path += current.countryName + " -> ";
				current = current.rightChild;
			}
			if(current == null)
			{
				return - 1; //search failed
			}
		}
		System.out.println(path += current.countryName);
		return current.hapIndex; //found but return hapIndex
	}
	/**<p>
	 * This is our delete method used when the user selects the 5th menu option, 'Delete a country for a given name', It is largely based
	 * off of the delete method demonstrated in the textbook on pg.408 'tree.java'. It utilizes a largely similar logical approach with slight
	 * modification such as the use of compareToIgnoreCase in order to compare the node to be deleted with the nodes on the BST. The delete method contains
	 * 4 cases in which deletion may fall under which are when the node to be deleted has no children, one child (left), one child (right), and or if
	 * the node to be deleted has 2 children nodes. Additionally, it also relies on a method for retrieving the successor similarly to the example code
	 * to properly retrieve the successor to use for node reassignment in the event the node to be deleted has 2 children nodes. If the country to be deleted
	 * was found during traversal, the user is prompted that the country name entered has been deleted. If the country entered cannot be found, then the user is informed
	 * regarding the failed operation./
	 * </p>
	 * <p>
	 * As it traverses in search of the country to delete, we can see that since the country names are being compared lexicographically, it uses a similar approach
	 * as our find method to determine whether or not to travel left or right at a given node. when we reach the node to be deleted, we can fall under 4 different sets of 
	 * operation based on the condition. 
	 * </p>
	 * <p>
	 * If we reach a node with no children nodes (our first if condition) then the node can simply be removed from the tree by setting the child references to null, essentially deleting
	 * it from the tree.
	 * </p>
	 * <p>
	 * If we reach a node with 1 child node (only left) (second If condition), then the node is removed by linking its parent to the left child. This operation bypasses the node to be deleted
	 * essentially removing it from the tree while still maintaining the left child as a left-side node.
	 * </p>
	 * <p>
	 * If we reach a node to be deleted having one child (Only right this time)(third If condition), then the deletion process is similar to the previous condition where the node is removed
	 * by linking its parent to the right child instead. By doing so, this bypasses the node to be deleted effectively removing it from the tree and reassigning the right child to be the right
	 * child of the parent.
	 * </p>
	 * <p>
	 * If we reach a node to be deleted having 2 child nodes (fourth If/else Condition), then we must call on our method to determining and retrieving the successor as reassignment becomes a bit more
	 * complex. When the getSuccessor method is called, the method looks for the next highest name value lexicographically that comes after the node being deleted. When the successor is found, the successor is used to take
	 * place of the node to be deleted to essentially remove it from the BST. However, based on where the node to be deleted is positioned on the tree the reassignment process differs slightly in
	 * each case such as; if the node to be deleted is the root of the tree, then the successor simply becomes the new root. If the node to be deleted is a left child node, then the successor is 
	 * assigned as the left child of the parent. And if the node to be deleted is a right child node, then the successor is assigned as a right child of the parent. 
	 * 
	 * By taking account in the possible scenarios our deletion and node to be deleted may fall on, we can take proper steps in reassignment to ensure the maintenance of our BST. 
	 * </p>
	 * @param name The name of the country to be deleted from the BST
	 */
	public void delete(String name)
	{
		Node current = root;
		Node parent = root;
		boolean isLeftChild = true;
		
		while(current != null && !current.countryName.equalsIgnoreCase(name))
		{
			parent = current;
			int key = name.compareToIgnoreCase(current.countryName);
			if(key < 0 )
			{
				isLeftChild = true;
				current = current.leftChild;
			}
			else
			{
				isLeftChild = false;
				current = current.rightChild;
			}
		}
		
		if(current == null)
		{
			System.out.println("The name provided: " + name + " Could not be found in the BST. No Deletes were made.");
			return ;
		}
		else
			System.out.print("Country: " + name + " has been deleted.");
		
		//No Children case
		if(current.leftChild == null && current.rightChild == null)
		{
			if(current == root)
			{
				root = null;
			}
			else if(isLeftChild)
			{
				parent.leftChild = null;
			}
			else
			{
				parent.rightChild = null;
			}
		}
		
		//One child case (no right child)
		else if(current.rightChild == null)
		{
			if (current == root)
			{
				root = current.leftChild;
			}
			else if(isLeftChild)
			{
				parent.leftChild = current.leftChild;
			}
			else
			{
				parent.rightChild = current.leftChild;
			}
		}
		//one child case (No left child)
		else if(current.leftChild == null)
		{
			if(current == root)
			{
				root = current.rightChild;
			}
			else if(isLeftChild)
			{
				parent.leftChild = current.rightChild;
			}
			else
				parent.rightChild = current.rightChild;
		}
		//Node has 2 child!
		else
		{
			Node successor = getSuccessor(current);
			
			if(current == root)
			{
				root = successor;
			}
			else if(isLeftChild)
			{
				parent.leftChild = successor;
			}
			else
			{
				parent.rightChild = successor;
			}
			successor.leftChild = current.leftChild;
		}
	}
	/**
	 * <p>
	 * This is the getSuccessor method that is invoked whenever the user selects the 5th menu option and the country name given has 2 children
	 * nodes in the BST. It is largely based off of the 'getSuccessor' method used in pg.410 'tree.java'. When the node to be deleted has 2 children,
	 * this method properly reassigns the children nodes to other nodes in order to maintain the link of the BST, ensuring that we only have one BST after
	 * a node has been deleted. 
	 * </p>
	 * <p>
	 * When the node to be deleted has 2 child nodes, this method is invoked to find a new successor. First, the node to be deleted is passed to the method as 'delNode'
	 * in which delNode is used to initialize the successorParent and the successor while current is set to the right child of the node to be deleted. 
	 * </p>
	 * <p>
	 * Then, the first while loop starts traversal in search of the successor, starting from the node to be deleted. As it continues to traverse, at each iteration it keeps
	 * reassigning successorParent to successor, successor to current, and current to current's left child. As it's traversing, it is aiming to find the node with the lowest 
	 * name value thats still greater than the node to be deleted (the immediate successor essentially). 
	 * </p>
	 * <p>
	 * Once the successor is found and is not a right child of the node to be deleted, then the right child of the successor is assigned as the left child of the 'successorParent' and the 
	 * right child of the node to be deleted is assigned as the right child of the successor, This effectively prepares the successor to take the place of the node to be deleted while still
	 * ensuring the integrity of the BST. Then after reassignment, the successor is returned to the delete method to use as a replacement for the node to be deleted.
	 * </p>
	 * 
	 * @param delNode The Node to be deleted
	 * @return successor The successor node that will replace the node to be deleted.
	 */
	private Node getSuccessor(Node delNode)
	{
		Node successorParent = delNode;
		Node successor = delNode;
		Node current = delNode.rightChild;
		
		while(current != null)
		{
			successorParent = successor;
			successor = current;
			current = current.leftChild;
		}
		
		if(successor != delNode.rightChild)
		{
			successorParent.leftChild = successor.rightChild;
			successor.rightChild = delNode.rightChild;
		}
		
		return successor;
	}
	/**<p>
	 * This is our printing method used to print the contents of the the BST In-orderly (LNR). It uses a similar approach demonstrated
	 * in pg.410 - 411 where when the printInorder Method is invoked, it calls an inOrder method and passes the root to print the 
	 * nodes recursively following the inOrder logical process of left, node, right (LNR).
	 * </p>
	 * <p>
	 * When printInOrder is invoked, the method calls on the inOrder method passing the value of root as the starting point for the traversal
	 * method. This method recursively traverses the array using the conditional value of localRoot that's being recursively passed throughout
	 * this process. as it visits each node, the details of each node is passed to the printNode method found in the Node class to print the details
	 * of each country in orderly to the user. The traversal method then ends once the base case has been reached (localRoot == Null - It has reached
	 * the end of the BST)
	 * </p>
	 * 
	 */
	//public int count;
	public void printInorder()
	{
		//count = 0;
		inOrder(root);
		//System.out.println("Number of Nodes: " + count);
	}
	public void inOrder(Node localRoot)
	{
		if (localRoot != null)
		{
			inOrder(localRoot.leftChild);
			localRoot.printNode();
			//count++;
			inOrder(localRoot.rightChild);
		}
	}
	
	/**
	 * <p>
	 * This is our printing method used to print the contents of the BST in Pre-order (NLR). It uses a similar approach demonstrated on
	 * pg. 410 - 411, 'Tree.java', where when the printPreOrder method is invoked, it calls on the preOrder method passing the value of root
	 * to traverse and print the nodes recursively following the logical traversal method of node, left node, then right.  
	 * </p> 
	 */
	public void printPreOrder()
	{
		preOrder(root);
	}
	public void preOrder(Node localRoot)
	{
		if (localRoot != null)
		{
			localRoot.printNode();
			preOrder(localRoot.leftChild);
			preOrder(localRoot.rightChild);
		}
	}
	/**
	 * <p>
	 * This is our printing method used to print the contents of the BST in post-order (LRN). It uses a similar approach demonstrated on pg.
	 * 410 - 411, 'Tree.java'. When the printPostOrder method is invoked, it calls on the postOrder method passing the value of root to traverse 
	 * and print the nodes recursively following the logical traversal method of post order; Left node, Right node, then node.
	 * </p> 
	 */
	public void printPostOrder()
	{
		postOrder(root);
	}
	public void postOrder(Node localRoot)
	{
		if(localRoot != null)
		{
			postOrder(localRoot.leftChild);
			postOrder(localRoot.rightChild);
			localRoot.printNode();
		}
	}
	
	
	/**
	 * <p>
	 * This is the printBottomCountries method that is invoked when the user selects the 7th menu option 'Print Bottom Countries regarding
	 * happiness'. When this method is invoked, the user is prompted to provide the number of countries they wish to retrieve from the BST
	 * that has the lowest happiness index which is the value of c. When this value is given, it is used to assign the size of the array to
	 * use in order to list the bottom countries on to our array ascendingly by calling on inOrderBotCountries to populate the array. When it
	 * calls this method, the value of root, the array, and the value of c is passed to the method to use as constraints for traversal and 
	 * retrieval. Once the method recursively populates the array with the bottom countries, a simple for loop is used to print the contents
	 * of the array. Additionally, if the value of c given is greater than the number of nodes in the BST, the operation still continues and 
	 * the array is still populated with all the nodes and prints them in order from the lowest happiness index to the highest.
	 * </p> 
	 * @param c
	 */
	public void printBottomCountries(int c)
	{
		Node[] botCountries = new Node[c];
		inOrderBotCountries(root, botCountries, c);
		for(int i = 0; i < botCountries.length; i++)
		{
			if(botCountries[i] != null)
			{
				botCountries[i].printNode();
			}
		}
	}
	/**
	 * <p>
	 * For our method for printing the c number of bottom countries, we rely on a method that uses an inOrder traversal method previously
	 * used on our first 3 menu options. This is to ensure that when this method is invoked, we traverse the entire tree in search of the bottom
	 * countries that has to be inserted onto our BST. In addition to this, as it follows this traversal method recursively, the method used to insert
	 * the bottom countries onto an array is derived and reused from project 2 (insertion onto a priorityQ) in order to insert our bottom countries onto
	 * our array in ascending order. By reusing this insertion method, we can traverse the array and store the values of the countries with the lowest happiness index.
	 * When the array reaches it's capacity (c), and a qualifying node is found, our insertion method tries to find the proper placement of the object onto the array and 
	 * shifts the remaining elements down to the right. through this shifting, elements that fall outside the capacity range of the array are essentially pushed off inorder 
	 * to only account for the c number of countries in the array. Once traversal is finished, our array should now contain the countries with the lowest happiness index inserted 
	 * in ascending order onto our botCountries array without having to rely on a sorting algorithm.
	 * </p>
	 * <p>
	 * As for our insertion operation, it mostly remains unchanged aside from utilizing an isFull check before insertion to ensure we don't go over the specified
	 * capacity. This was mostly necessary since in project 2 we allocated ample space for our array to allow insertion at the very beginning without hitting the 
	 * maximum, however in this project, since we are limited to the size of c given by the user, checks before insertion is necessary to avoid outofbound exceptions.
	 * </p>
	 * 
	 */
	public void inOrderBotCountries(Node localRoot, Node[] botCountries, int c)
	{
		if (localRoot != null)
		{
			inOrderBotCountries(localRoot.leftChild, botCountries, c);
			
			int j;
			for(j = c - 1; j >= 0; j-- )
			{
				if(botCountries[j] == null || localRoot.hapIndex < botCountries[j].hapIndex)
				{
					if(botTopArrayIsNotFull(botCountries, j))
						botCountries[j + 1] = botCountries[j];
				}
				else
					break;
			}
			if(botTopArrayIsNotFull(botCountries, j))
				botCountries[j + 1] = localRoot;
			
			inOrderBotCountries(localRoot.rightChild, botCountries, c);
		}
	}
	
	/**
	 * <p>
	 * To Print our top countries, which is our 8th menu option, we rely on a similar approach we used for the bottom countries. When the 8th option
	 * is selected, the user is prompted to provide the number of countries they wish to retrieve from the BST. This number is the value of c that we use
	 * to initialize the size of our array. Once this value has been provided, we call on inOrderTopCountries, based off of our inOrder traversal method
	 * to traverse through the tree in search of the countries with the highest happiness index value. Once it finishes traversing recursively in in-order
	 * fashion, then the contents of the array is printed containing the c number of top countries based on happiness index. 
	 * </p>
	 * 
	 * @param c The number of countries / the array size provided by the user. 
	 */
	public void printTopCountries(int c)
	{
		Node[] topCountries = new Node[c];
		inOrderTopCountries(root, topCountries, c);
		for(int i = 0; i < topCountries.length; i++)
		{
			if(topCountries[i] != null)
			{
				topCountries[i].printNode();
			}
		}
	}
	/**
	 * <p>
	 * Our inOrderTopCountries method, in charge of traversing and inserting onto our array is similarly structured to that of the method we used to retrieve
	 * our bottom countries. The structure of the method is still based off of our inOrder traversal to ensure we visit every node in search of the top countries
	 * and our insertion method is still derived from project 2 's insertion onto a priorityQ. The only difference with this method is that it stores the value in the
	 * array in descending order, meaning that the country of the highest happiness index value is the first to be listed. 
	 * 
	 * Like in our previous method, we call on another method, 'botTopArrayIsNotFull' to ensure space for insertion/shifting. 
	 * </p>
	 * 
	 * @param localRoot
	 * @param topCountries
	 * @param c
	 */
	public void inOrderTopCountries(Node localRoot, Node[] topCountries, int c)
	{
		if (localRoot != null)
		{
			inOrderTopCountries(localRoot.leftChild, topCountries, c);
			
			int j;
			for(j = c - 1; j >= 0; j--)
			{
				if(topCountries[j] == null || localRoot.hapIndex > topCountries[j].hapIndex)
				{
					if(botTopArrayIsNotFull(topCountries, j))
						topCountries[j + 1] = topCountries[j];
				}
				else
					break;
			}
			if(botTopArrayIsNotFull(topCountries, j))
				topCountries[j + 1] = localRoot;
			inOrderTopCountries(localRoot.rightChild, topCountries, c);
		}
	}
	
	
	/**
	 * <p>
	 * This is our isFull method used to check if the array we use in retrieving the top/bottom countries are full. We rely on this method before insertion
	 * since we are working with limited space compared to project 2 where we were able to allocate extra space for testing. This method, when invoked, essentially
	 * checks if there is space available in the array for insertion or shifting if a new qualifying node was found.We do this by passing the array onto the method along with the index (j), and 
	 * as long as the index does not equal the end index of the array, the method returns true signifying that we have not reached the end and insertion can continue.
	 * if the method returns false, then this implies that the array is at capacity and no insertion can be made.
	 * </p>
	 * 
	 * @param array The array containing the top or bottom countries
	 * @param index The index of the array being passed (variable j)
	 * @return True or False based on the value of j being passed.
	 */
	private boolean botTopArrayIsNotFull(Node[] array, int j)
	{
		return j != array.length - 1;
	}
	
}









