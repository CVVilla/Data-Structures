/**
 * @author Calvin Villanueva
 * @version 12/10/2023
 * <p>
 * This is the HashTable.java class for Project 5. The structure of this code is primarily derived from the example code demonstrated in chapter 11, Hash Tables, "hashChain.java" starting on page 555 where a standard implementation
 * of hash tables using separate chaining is demonstrated. Additionally, since for this project, we rely on a double-ended singly linked list, we also refer to a previous chapter, Chapter 5 (Linked Lists) to follow the initialization
 * and implementation of a double-ended singly linked list. Since we are using a double ended linked list and insertion must occur at the end of the link, we use the core logic of insertLast onto our insert function to maintain the order
 * in which elements are inserted at a specified index dictated by the hash function. 
 * </p>
 * 
 * <p>
 * The HashTable.java class contains the core logic behind our separate chaining based hash table for all of the operations provided to the user by the menu in project5.java. When the code is executed, the user is first prompted to provide
 * the csv file name to open (Countries5.csv). When this is given, our while loop in project5.java iterates over the csv file to capture the data we aim to focus on in this project, which is the country name, its population and its area for each
 * line of entry. Each entry is then inserted by invoking the insert method from the HashTable class in which the country name is passed to the hash function to determine the correct index in which the country should be stored based on the unicode value
 * of the name. Once the hash function returns this index value, the country is then inserted at the link list in the given index. Any subsequent countries inserted in the same index is then inserted at the end of the linked list by using the last pointer
 * of our double-ended singly linked list in order to maintain the order in which countries were inserted. When all the entries in the csv file has been parsed, the user is then presented with the menu in which they have the option to perform the given
 * operations:
 * </p>
 * 
 * <p>
 * 1. Print the hash table - The print hash table menu function relies on 3 methods here in HashTable.java, which are printNode, displayList, and displayTable. printNode is primarily in charge of printing the details of each node within the linked list. 
 * it is responsible for calculating the population density by dividing a given country's population against its area , printing the country name stored at the node, and formating the values to 4 digits after the decimal point to adhere to the project
 * requirement. the displayList method is used in conjunction with the printNode method, as the displayList method is primarily responsible for traversing the linked list at given index. If the linked list is populated, displayList traverses through the nodes
 * and calls the printNode method to print the details of each countries within the linked list. And lastly, the displayTable method relies on displayList as it traverses the array. As displayTable increments upwards towards the end of the array, for each index
 * that it encounters that has an empty linked list, "empty" is then printed at the given cell to denote that no countries are stored here. If it encounters an index thats not empty, then it calls on displayList, which in conjunction, calls on printNode to print
 * the details of the countries stored in the hash table per index. 
 * </p>
 * 
 * <p>
 * 2. Delete a country of a given name - the delete methods in our hashTable.java relies on one another in order to locate the given country name to locate the index in which it's stored and delete it from the linked list. When delete is invoked, the delete method
 * from the HashTable class invokes the hash function method in order to determine the index in which the given country name would be stored at. This value is then passed as a direct index address to the delete method in our DELinkedList class which then traverses
 * the linked list comparing the given name against the names stored in each link in order to find the country to delete. when found, the pointers in the given liked list is then reassigned to effectively remove the link at the specified index as well as maintain 
 * the integrity of the linked list. If the country entered cannot be found at the specified index, then the user is informed that delete has failed as the country could not be located within the hash table. 
 * </p>
 * 
 * <p>
 * 3. Insert a county of its name, population and area - Our insert methods takes a similar approach as when we first insert countries onto our hash table from the csv file. When invoked, our insert methods (insert and insertLast) work together along with the hash function method in order to
 * determine which index the country should be stored at given it's hash value after calculating the country name's unicode. Once the hash function returns this value, this index value is then passed as a direct index address for our insert method located in DELinkedList
 * to insert the country onto our linked list at the given index. If another country is added that results in being stored in the same index, then this country is then inserted at the end of the linked list in order to maintain the order in which they were inserted at the index.
 * Additionally, as for our insert method in the HashTable class, we've implemented an extra step to ensure that no countries of the same name are inserted on the same linked list at a given index.
 * </p>
 * 
 * <p>
 * 4. Search and print a country and its details - our search option relies on our find method from our DELinkedList class and from the HashTable class. When invoked, the user is first prompted to provide the country to search for in order to determine the index value in which the county wouldve
 * been inserted at based on its unicode value. When the index value is returned, the find method from the HashTable class then calls on the find method from the DELinkedList class along with the calculated hash index value of the given country name. The find method from the DELinkedList class then
 * traverses the linked list comparing the given country name against the country names stored in the linked list until it reaches the end. if found, then current is returned and the find method from the Hash Table class returns the hash index value to prompt the user which index the country was found.
 * if it reaches the end of the linked list and the country is not found, then null is returned in which results in returning a value of -1 as outlined in the project requirement to indicate a search failure. When the country is found, the returned int hash value is then used to print the specified country
 * to print it's population density by calling printNodePopDense(). 
 * </p>
 * 
 * <p>
 * 5. Print the number of empty cells and collided cells - for our method in charge of counting empty collided cells, we take a similar approach as we did displayTable method from our HashTable class, as the displayTable method's core logic of traversing the array is what we will primarily need to count the
 * number of empty and collided cells within our hash table. As it traverses the array and increments upwards at each index, our method simply checks if the linked list at each index is empty using the isEmpty method. if it is then the emptyCells counter is incremented by 1. As for collided cells, a simple 
 * check is used to ensure that the first node and the node next to it exists (!= null). If it does, then this means more than one node is stored at the linked list since the second node != null, satisyfing our condition for collision. we then increment the counter by 1 aswell to display the total amount of
 * collided and empty cells to the user.
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Hash Tables  - Textbook </b> - Chapter 11 Hash Tables, Page 555 - 560, "hashChain.java"
 * 		- class Link
 * 		- public void displayLink()
 * 		- class SortedList
 * 		- public void delete()
 * 		- public Link find()
 * 		- public void displayList()
 * 		- class HashTable
 * 		- public HashTable()
 * 		- public void displayTable()
 * 		- public void insert()
 * 		- public void delete()
 * 		- public Link find()
 * 	<li><b>Hash Tables  - Textbook </b> - Chapter 11 Hash Tables, Page 564 - 565, "hashFunc1" & "hashFunc2"
 * 		- public static int hashFunc1()
 * 		- public static int hashFunc2()
 *  <li><b>Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 198 - 200, "firstLastList.java"
 *  	- class firstLastList
 *  	- public boolean isEmpty()
 *  	- public void insertLast()
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing  
 * <ol>
 * </p>
 * 
 * <p>
 * Our node class represents the 'Link' class from hashChain.java. We use this method to hold the values of individual elements being inserted onto our hash table focusing on 3 primary attributes about a specific county, the name, population
 * and the area of said country. Additionally, reference to the next node is also initialized here so that we can traverse left to right at a specific index within the double-ended linked list. The constructor for the node class can also be found here
 * along with the printNode method to calculate and print the details of a specific node as specified by the requirements. Additionally, printNodePopDense can also be found here and is modeled similarly to printNode specifically just for printing the
 * population density of a given country. This is added primarily to mimic the same output as the project example where the index of the given country is given to the user along with just the country's population density.
 * </p>
 */

class Node
{
	String name;
	double population;
	double area;
	Node nextNode;
	
	public Node(String name, double population, double area)
	{
		this.name = name;
		this.population = population;
		this.area = area;
		this.nextNode = null;
	}
	
	public void printNode()
	{
		double popDense = population / area;
		System.out.printf("%-40s %-15.4f\n", name, popDense);
	}
	
	public void printNodePopDense()
	{
		double popDense = population / area;
		System.out.printf("%-15.4f\n", popDense);
	}
}
/**
 * <p>
 * Our DELinkedList class represents the SortedList class from hashChain.java. The main difference between the example and the implementation is that we utilize a double-
 * ended singly linked list instead of the traditional singly linked list, as stated on the project requirements. The use of a double-ended singly linked list is primarily
 * for our insertion method which is derived from a previous chapter, Chapter 5 Linked List, 'firstLastList' utilizing the insertLast method to insert at the end of our linked
 * list.
 * </p> 
 */
class DELinkedList
{
	public Node first;
	public Node last;
	
	public void DELinkedList()
	{
		first = null;
		last = null;
	}
	
	public boolean isEmpty()
	{
		return first == null;
	}
	/**
	 * <p>
	 * Since the project requirements states that insertion must occur at the end of the linked list and since we have the ability to use the last
	 * pointer through our double-ended singly linked list, we can simply use the insertLast method from Chapter 5, Linked List to insert new countries located in the same index
	 * towards the end of the linked list. This allows us to see which countries were processed first as they're inserted at a specified index dictated by our hash function.
	 * This means that if two countries results in being inserted at the same index, the first country inserted should be listed first on the list and the second country to be inserted
	 * right after. Our insert method also makes use of our isEmpty method similarly to our previous project 2 & 3 so that we can ensure proper assignment when a country is first to be
	 * inserted onto our double-ended linked list hash table. the isEmpty method simply checks if the value of first == null. if true, then the new country to be inserted is now the first
	 * while subsequent countries right after are assigned as the next node of last, effectively inserting towards the end.
	 * </p>
	 * 
	 * @param name The name of the country node to be inserted
	 * @param population the population of the country node to be inserted
	 * @param area the area of the country node to be inserted
	 */
	public void insertLast(String name, double population, double area)
	{
		Node newNode = new Node(name, population,area);
		if(isEmpty()) 
		{
			first = newNode;
		}
		else
		{
			last.nextNode = newNode;
		}
		last = newNode;
	}
	
	/**<p>
	 * Our find method is similarly based off of the find method demonstrated on hashChain.java. This method first relies on our hash functions in order to find the specific index in which
	 * the given country name was stored. When the hash function calculates the index value, the index is then passed to the find method along with the country name to traverse the linked list
	 * from start to end until the given country name is found. When found, then the value of current is returned containing the country details of the given country. If the search fails, then null
	 * is returned and the user is prompted that the given country name could not be found. By implementing our search function in such a way, we can achieve reducing our search time effectively since 
	 * our hash function ensures that we only traverse the linked list at a specified index, removing the need to traverse all of the linked list in order to find the given country.
	 * </p>
	 * 
	 * @param name The country name to search for at a given index in the linked list after hash calculation
	 * @return current/null is returned if found/not found
	 */
	//hashChain.java
	public Node find(String name)
	{
		Node current = first;
		while(current != null)
		{
			if(current.name.equals(name))
			{
				return current;
			}
			current = current.nextNode;
		}
		return null;
	}	
	/**<p>
	 * Our delete method is similarly based off of the delete method demonstrated on hashChain.java. This method, similarly to find, relies on our implemented hash function to locate the specific index in
	 * which the country to be deleted would be located. When the delete method is at the specified index, it traverses the linked list similarly to find in search of the country to delete. As it traverses
	 * the specified index, the delete method will encounter one of the cases which is when the country to be deleted is first , in the middle, last or nowhere to be found on the linked list. 
	 * </p>
	 * 
	 * <p>
	 * If the country to be deleted is first (previous == null), first is then updated as the next node, effectively cutting the first off and making the next element the new first. If there is no other elements
	 * on the linked list, meaning it was the only elements at the specified index, then last is set to null.
	 * </p>
	 * 
	 * <p>
	 * If the country to be deleted is somewhere in the middle (our else statement), then the element is effectively deleted by updating the nextNode of previous to go over the current node, effectively cutting
	 * current out. 
	 * </p>
	 * 
	 * <p>
	 * If the country to be deleted is last (current == last), then the last pointer is reassigned to the previous node before last, making the previous node the new last. cutting the original off.
	 * </p>
	 * 
	 * <p>
	 * If the country to be deleted cannot be found (current == null), then no deletion occurs and the user is prompted that the given country name could not be found within the linked list where it would be 
	 * located.
	 * </p>
	 * 
	 * @param name The country name to search for to delete at the given index within the linked list
	 */
	public void delete(String name)
	{
		Node previous = null;
		Node current = first;
		
		while(current != null && !current.name.equals(name))
		{
			previous = current;
			current = current.nextNode;
		}
		if(current == null)
		{
			System.out.println("The country name: " + name + " Could not be found! Delete failed.");
			return;
		}
		
		if(previous == null)
		{
			first = first.nextNode;
			if(first == null)
			{
				last = null;
			}
		}
		else
		{
			previous.nextNode = current.nextNode;
			if (current == last)
			{
				last = previous;
			}
		}
	}
	
	/**
	 * <p>
	 * Our displayList method is primarily derived and based off of the displayList method demonstrated on hashChain.java. When this method is invoked by the 1st menu option to print the hash table,
	 * this method is in charge of traversing the double-ended singly linked list at each index to print the contents of the linked list. for each index, the node denoted by 'current' is then passed to the printNode
	 * method in order to retrieve and print the country name and the population density of the given node. Additionally, if the linked list is populated by more than 1 node, then an if statement is used to add 
	 * additional spaces to the subsequent nodes after first in order to align the countries neatly against the first node at the given index. The displayList method traverses the linked list at the given index 
	 * until it reaches the end, in which it would move to the next index to repeat the same process.
	 * </p>
	 */
	public void displayList()
	{
		Node current = first;
		while(current != null)
		{
			current.printNode();
			if(current.nextNode != null)
			{
				System.out.print("     ");
			}
			current = current.nextNode;

		}
	}
	
	
	
}
/** <p>
 * This is our hashTable class that utilizes a similar approach demonstrated on hashChain.java, 'HashTable'. Our HashTable class is primarily in charge of initializing the the array we will use for our linked list
 * in order to achieve separate chaining. As specified, our array size is set to be double the number of elements we insert + 1 (257) in order to use this value for our hash function found in this class and avoid collisions
 * like mentioned in Chapter 11. Additionally,this is where the caller method for insert, deleted and find can also be located, as when the methods are invoked and a given country name is provided, the country name is then passed 
 * to the hash function in order to locate which index the specified country would be located. Lastly, our methods for displaying the HashTable and counting the empty and collided cells can also be found within our HashTable class. 
 * </p>
 */
//hashChain.java
public class HashTable 
{
	public DELinkedList[] hashArray;
	private int arraySize;
	
	/**
	 * This is our constructor for the HashTable class primarily in charge of initializing our array based on the set size of 257 as well as initializing each index as an empty linked list to use for our double-ended
	 * linked list. 
	 * 
	 * @param size The array size set in Project5.java (257)
	 */
	public HashTable(int size)
	{
		arraySize = size;
		hashArray = new DELinkedList[arraySize];
		for(int i = 0; i < arraySize; i++)
		{
			hashArray[i] = new DELinkedList();
		}
	}
	//hashFunc1 & 2 pg 564
	/**<p>
	 * Our hashFunc method is a core component of our hash table and is primarily derived from the provided examples in chapter 11, hashFunc1 and hashFunc2. our hash function uses the length of the given sting
	 * in order to traverse from left to right to calculate the unicode value of each letter (i) and summing it up at each letter using +=  to use as modulo against our array size to determine the index value 
	 * in which the given country name should be stored. The hash function uses the array size of 257 which is double the expected number of elements + 1 in order to use this value to avoid collisions for separate
	 * chaining. 
	 * </p>
	 *  
	 * @param name The country name to calculate the unicode value to use as a variable for our hash calculation against the set array size of 257 using modulo.
	 * @return the value of the hash after calculation to use as the index
	 */
	public int hashFunc(String name)
	{
		int hash = 0;
		for(int i = 0; i < name.length(); i++)
		{
			hash += name.charAt(i);
		}
		return hash % arraySize;
	}
	/**
	 * <p>
	 * This is our insert caller method primarily based off of the insert method demonstrated in hashChain.java. When this method is invoked, either by first parsing the data from the csv or the user manually inputing
	 * a country, the country name given is passed onto the hash function in order to determine which index the country should be stored at. Once the hash function returns the index value after calculation, the value
	 * of hash is then passed to the find method to traverse the linked list at the given index to check for duplicates before entry. If find returns null, signifying that there is no duplicate of the given country name,
	 * then the new node is inserted at the specified index at the end of the linked list. If the given country is already found at the specified index, then the user is prompted that insertion cannot be performed as
	 * the country already exists. 
	 * </p>
	 * 
	 * @param name The country name of the country node to be inserted
	 * @param population the population of the country node to be inserted
	 * @param area the area of the country node to be inserted
	 */
	public void insert(String name, double population, double area)
	{
		int hash = hashFunc(name);
		if(hashArray[hash].find(name) == null)
		{
			hashArray[hash].insertLast(name, population, area);
		}
		else
		{
			System.out.println("Error! insertion failed! this country already exists!");
		}
	}
	/**<p>
	 * This is our delete caller method primarily based off of the delete method demonstrated in hashChain.java. Similarly to insert, when this method is invoked by the user, the user is first prompted to provide the 
	 * country name to delete. When provided, the string is then passed to this method which then passes it to the hash function method to calculate the index value in which the string will be located at. This value
	 * is then returned by the hash function and is then used as a direct address for the delete method to traverse the linked list in search of the given country name. 
	 * </p>
	 * 
	 * @param name the country name of the node to pass to the hash function to determine the index address to traverse for deletion
	 */
	public void delete(String name)
	{
		int hash = hashFunc(name);
		hashArray[hash].delete(name);
	}

	/**<p>
	 * This is our find caller method primarily based off of the find method demonstrated in hashChain.java. Like the previous caller methods, when this method is invoked by the user, the user is first prompted to provide
	 * the country name to search for. Once the country name has been given, this country name is then passed to the hashFunc in order to calculate the index in which the country would be inserted onto by our insert method.
	 * After calculation, the value returned is used as a direct index address in the array to use for our find method in or DELinkedList class. Our find method there will then traverse the specified linked list until the 
	 * country is found or if the search fails. If found, then the hash index value is returned to prompt the user that the country is located at the specified index. If the search fails, then -1 is returned to signify that
	 * the country at the given index could not be found. 
	 * </p>
	 * 
	 * @param name the country name of the node to pass to the hash function to determine the index address to traverse to locate the given country name.
	 * @return The index value of the found country or -1 if the country was not found at the specified index
	 */
	public int find(String name)
	{
		int hash = hashFunc(name);
		if(hashArray[hash].find(name) != null)
		{
			return hash;
		}
		return -1;
	}
	/**<p>
	 * This is our displayTable method primarily based off of the displayTable method demonstrated in hashChain.java. When this method is invoked by the user, the size of the array is used for our for-loop to incremently
	 * traverse the array at each index. As we arrieve at each index, we rely on an if statement along with our isEmpty method to determine if the linked list at a given index is empty or is populated. If it is empty, 
	 * meaning first = null at the given linked list, then we display "empty" to signify that the linked list is empty at the specified index. If not, then we pass the index value to displayList to print the nodes in the
	 * order in which they were inserted at the specified index.
	 * </p>
	 */
	//hashChain.java (possible option to use to count Collided/empty cells
	public void displayTable()
	{

		for(int i = 0; i < arraySize; i++)
		{
			System.out.printf("%3d. ",i);
			if(hashArray[i].isEmpty())
			{
				System.out.println("Empty");
			}
			else
			{
				hashArray[i].displayList();
			}
		}
	}
	
	/**<p>
	 * This is our printEmptyAndCollidedCells method that is primarily derived from our displayTable code in order to count the number of empty cells/indexes and counting the number of collided cells. Collided cells can be loosely
	 * defined as when an a specific index contains more than one node, meaning another country name resulted in being stored at an index that is already populated. For this method, similarly to our displayTable method, relies
	 * on a for loop and the array size to traverse the array at each index. For each index it increments over, the linked list at the specified index is checked using isEmpty to see if first != null. if it does (linked list is empty at the specified index), 
	 * then the counter for counting empty cells is incremented by 1. As for collisions, we use a similar logic to compare the first node against the node next to it since our main focus is to see if more than 2 nodes exist in the hashed linked list.
	 * if there are more than one node in a linked list AND the first and second node doesn't = null, then this means there are at least 2 valid nodes in the linked list and we increment our collidedCells counter. 
	 * 
	 * Once the for-loop reaches the end of the array, the number of empty cells and the number of cells containing more than 1 node (collisions) is then presented to the user.
	 * </p>
	 */
	public void printEmptyAndCollidedCells()
	{
		int emptyCells = 0;
		int collidedCells = 0;
		
		for(int i = 0; i < arraySize; i++)
		{
			if(hashArray[i].isEmpty())
			{
				emptyCells++;
			}
			//first != null and first.nextNode != null infers that 2 valid nodes exists in linked list [i].
			if(hashArray[i].first != null && hashArray[i].first.nextNode != null)
			{
				collidedCells++;
			}
		}
		
		System.out.println("The Number of Empty Cells: " + emptyCells);
		System.out.println("The Number of Collided Cells: " + collidedCells);
	}
}
