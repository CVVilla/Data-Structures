import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * @author Calvin Villanueva
 * @version 12/10/2023
 * 
 * <p>
 * This is the Project 5 class containing the main driver for our program. The main method has largely main unchanged from the last project and has been modified slightly
 * to fit our requirements for project 5, such as the initialization of the hashArray with the specified size of 257, the while loop which now only focuses on the country name,
 * population, and area. and the functionalities of the repeating menu options provided to the user. The purpose of this project is to implement a hash table that utilizes a double
 * ended singly linked list with the use of separate chaining to process the countries from the csv file onto a specific index specified by our hash function formula. When the program
 * is executed, main is predominately in charge of 3 main components; First, it prompts the user to provide the file name for the csv file we wish to parse (Countries5.csv). Second, when
 * the valid file name has been given, the first while loop processes each entry from the csv file only capturing the country name, population and area. During this process, the insertion of
 * each entry is dictated by the hash function in order to calculate which index each country should be stored at based on their country name's unicode value after hashing. and lastly, the 
 * repeating menu which the user can interact with in order to manipulate the hash table until prompted to quit.
 * </p>
 * 
 * <p>
 * Our menu contains error catches in the event the user enters values that are outside the given range for the menu (1-6), and if the value entered is not numeric.
 * Additionally, for our insert method, since the given value of population and area are calculated against one another, we also have an error check in order to ensure
 * that the values the user provide during insertion is of numeric type before insertion. Lastly, although its further explained in HashTable.java, our insert method also
 * contains an error check to ensure that no country of the same identical name are inserted at the same index. This is to ensure that we have no exact duplicates within our
 * hash table.
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Hash Tables  - Textbook </b> - Chapter 11 Hash Tables, Page 555 - 560, "hashChain.java"
 * 		- class Link
 * 		- public void displayLink()
 * 		- class SortedList
 * 		- public void delete()
 * 		- public Link find()
 * 		- public void displayList()
 * 		- class HashTable
 * 		- public HashTable()
 * 		- public void displayTable()
 * 		- public void insert()
 * 		- public void delete()
 * 		- public Link find()
 * 	<li><b>Hash Tables  - Textbook </b> - Chapter 11 Hash Tables, Page 564 - 565, "hashFunc1" & "hashFunc2"
 * 		- public static int hashFunc1()
 * 		- public static int hashFunc2()
 *  <li><b>Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 198 - 200, "firstLastList.java"
 *  	- class firstLastList
 *  	- public boolean isEmpty()
 *  	- public void insertLast()
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing  
 * <ol>
 * </p>
 */
public class Project5 
{	

	public static void main(String[] args) 
	{
		
		//initialize size to 257
		HashTable hashTable = new HashTable(257);
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the name of the file to open (Countries5.csv) ");
		String fileName = input.next();
		System.out.println("Opening File: " + fileName);
		Scanner file = null;

		
		try
		{
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)//catch for invalud input
		{
			System.out.println("Error the file name entered cannot be found");
			System.exit(1);
			input.close();
		}
		
		file.nextLine();//skip the header!
		file.useDelimiter(",|\n");
		int elementCount = 0;
		
		while(file.hasNext())
		{
			String name = file.next();
			file.next();
			double population = Double.parseDouble(file.next());
			file.nextDouble();
			double area = Double.parseDouble(file.next());
			file.nextDouble();
	
			hashTable.insert(name, population, area);
			elementCount++;
		}

		file.close();//close scanner
		Scanner scanner = new Scanner(System.in);
		int option = 0;
		
		
		do
		{
			//Prompt the user menu
			MenuPrinter.menu(elementCount);
			
			try
			{
				option = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Option Selected: " + option);
			}
			catch(InputMismatchException e)//catch input that may not be digit
			{
				System.out.println("Invalid Option Selection, please enter a numeric value");
				scanner.nextLine();
				continue;
			}
			
			if(option == 1) //print HashTable
			{
				displayHeader();
				hashTable.displayTable();
			}
			
			if(option == 2) //Delete Country //move confirmation message to method
			{
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to delete:");
				String cNameToDel = inputScanner.nextLine();
				
				hashTable.delete(cNameToDel);		
				
			}
			
			if(option == 3) //Insert Country
			{
				double pop = 0;
				double area = 0;
				boolean isNumeric = false;
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to add:");
				String cName = inputScanner.nextLine();
				
				//ensure values are of numeric type
				while(!isNumeric)
				{
					try
					{
						System.out.print("Enter the Population for: " + cName + " ");
						pop = inputScanner.nextDouble();
				
						System.out.print("Enter the Area for: " + cName + " ");
						area = inputScanner.nextDouble();
						inputScanner.nextLine();
						isNumeric = true;
						
					}
					catch(InputMismatchException e)
					{
						System.out.println("Error! please only enter numeric values for population and area for " + cName);
						inputScanner.nextLine();
					}
				}
				hashTable.insert(cName, pop, area);

			}
			
			if(option == 4) //Search for Country
			{
				Scanner inputScanner = new Scanner(System.in);
				System.out.print("Enter the name of the country to search for:");
				String cName = inputScanner.nextLine();
				
				//call find to locate index
				int index = hashTable.find(cName);
				if(index == -1)//Name given could not be found at hashed index
				{
					System.out.println("Country: " + cName + " Could not be found. Search failed.");
				}
				else
				{
					//call again using found index (to retrieve the specific search node to pass to the found variable to print just pop-dense value)
					Node found = hashTable.hashArray[index].find(cName);
					System.out.print("Country: " + cName + " is found at Index: " + index + " with a population density of: ");
					found.printNodePopDense();
				}
			}
			
			if(option == 5) //Print empty and collided cells
			{
				System.out.println("Number of Elements inserted into hash table: " + elementCount);
				hashTable.printEmptyAndCollidedCells();
			}
			if(option == 6)//user selected the 6th menu option closing the program.
			{
				System.out.println("Thank you for a great semester and have a happy holliday! ");
				System.out.println("Exiting now.....");
			}
			if(option > 6 || option <= 0) //Out of bounds check
			{
				System.out.println("Invalid Option Selection, please enter an integer value between 1 - 6");
			}
			
		} while (option !=6);
		scanner.close();
		
	}
	
	public class MenuPrinter
	{
		public static void menu(int elementCount)
		{
			System.out.println("\n\nCOP3530 Project 5 - Hash tables");
			System.out.println("Author: Calvin Villanueva (N01068487)");
			System.out.println("\nThere were " + elementCount + " country records parsed into the hash table");
			System.out.println("\nPlease Select an option between 1 - 6\n"+
								"1 - Print Hash Table \n"+
								"2 - Delete a country of a given name \n"+
								"3 - Insert a country for its name, pupulation and area \n"+
								"4 - Search and print a country and its population density for a given name \n"+
								"5 - print the number of empty cells and collided cells \n"+
								"6 - Exit Program\n\n");		
		}
	}
	public static void displayHeader()
	{
		System.out.println("     Name                                  Population Density");
		System.out.println("-------------------------------------------------------------");
	}
}