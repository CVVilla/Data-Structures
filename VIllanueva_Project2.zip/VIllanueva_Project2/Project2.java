import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * @author Calvin Villanueva
 * @version 10/06/2023
 * <p>
 * This is the driver class for Project 2. Main is primarily in charge of handling and parsing the data from countries2.csv and storing the data
 * onto 2 arrays, our stack array and our priority queue array, with a fixed size of 150 to allow the tester to freely insert and remove elements
 * without hitting the maximum after execution and parsing. Once the user provides the appropriate file name (Countries2.csv), the data from the csv
 * file is parsed onto our 2 arrays and a repeating menu is presented to the user to view and manipulate the stack and priority queue.
 * </p>
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing
 *  <li><b>Project 1</b> - Reusing Country.java and most of the original code for main in Project1.java.
 * 	<li><b>Stacks and Queues</b> - Ch.4 - part 1 (Slide 8,9,10 & 12)
 * 	<li><b>Priority Queues</b> - Ch.4 - part 2 (Slide 6 - 8)
 * <ol>
 * </p>
 */
public class Project2 
{
	/**
	 * <b>This is the main function of project 2</b>
	 * <p>
	 * The main function is the driver class for project2 and is predominantly in charge 3 main components of Project2.
	 * </p>
	 * First it prompts the user to enter a file name to locate in order to parse it into our 2 arrays. For this project, it will be "Countries2.csv". 
	 * Once a correct filename is received it skips the first line containing the header and uses a delimiter to know when a new line is detected within the CSV file
	 * <p>
	 * secondly, it then uses a while loop to read and store each record in the file onto our stack and priority queue. Once the end of the file is reached, the scanner
	 * is closed and both arrays are now fully populated.
	 * </p>
	 * <p>
	 * then lastly, we can present the user with a repeating menu until the user selects the 7th option
	 * from this menu, the user can choose to view the contents of the stack and priority queue to see that the values from the csv are pushed or inserted onto the arrays.
	 * The stack should show the user that the last element to be pushed should be at the top of the stack, while the first element should be at the bottom as it was the
	 * first element to be pushed onto the array. Alternatively, for the priority queue, since we insert based on happiness index in order to use this value as our condition
	 * for priority, the User should see that the country with the highest priority be located at the "front" of the priority queue, and the element with the lowest happiness 
	 * index value be located at the "rear" of the priority queue.
	 * <p>
	 * When the user selects option 3 or option 6 to insert new countries onto the stack and queue, the menu will prompt the user asking for 6 data information
	 * regarding the new country to be added that is stored in an object to push or insert onto the stack or queue. If the user pushed a country onto the stack,
	 * the most recently added country should be at the top of the stack. If the user inserts on to the priority queue, then the country should be placed accordingly
	 * onto the priority queue based on the priority value of the happiness index given. 
	 * </p>
	 * 
	 * 
	 * <p>
	 * The main function contains error handling when it comes to the user inputing an invalid file name and an invalid menu choice selection
	 * The main function also has the necessary checks needed to see if the stack and queue is full/empty. If either condition is true, it will
	 * prompt the user that such action can't be performed until an element is in the array or additional space has been provided when it comes to
	 * push and insertion / pop and remove.
	 * </p>
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) 
	{
		//Array we will store in, we set the size to 150 to allow insertion after execution to avoid hitting the max.
		Stack countryStack = new Stack(150);
		PriorityQ countryPQueue = new PriorityQ(150);
		
		int recordCount = 0;
		
		Scanner input = new Scanner(System.in);
		//Prompt User for file name
		System.out.println("Please enter the name of the file to open (Countries2.csv) ");
		String fileName = input.next();
		System.out.println("Opening File: " + fileName);
		Scanner file = null;

		
		try
		{
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)//catch for invalud input
		{
			System.out.println("Error the file name entered cannot be found");
			System.exit(1);
			input.close();
		}
		
		file.nextLine();//skip the header!
		file.useDelimiter(",|\n");
		
		while(file.hasNext())//loop to fill Stack / P Queue
		{
			String name = file.next();
			String capital = file.next();
			double pop = file.nextDouble();
			double GDP = file.nextDouble();
			double area = file.nextDouble();
			double hapIndex = file.nextDouble();
			
			//store the value of a line from csv file to an object to use to push/insert into our Stack / PQueue
			Country countryObj = new Country(name, capital, pop, GDP, area, hapIndex);
			//push the country object to the stack in the order given in the input file
			countryStack.push(countryObj);
			//push the country object into the priority queue (in ascending order)
			countryPQueue.insert(countryObj);
			//count will continue to iterate as long as file.hasNext condition is met, effectively keeping count of the number of elements
			//being stored in the Stack and Priority Queues from the csv file.
			recordCount++;
		}
		file.close();//close scanner
		Scanner scanner = new Scanner(System.in);
		int option = 0;

		do
		{
			//Prompt the user menu
			MenuPrinter.menu(recordCount);
			
			try
			{
				option = scanner.nextInt();
				System.out.println("Option Selected: " + option);
			}
			catch(InputMismatchException e)//catch input that may not be digit
			{
				System.out.println("Invalid Option Selection, please enter a numeric value");
				scanner.next();
				option = 0;
			}
			
			if(option == 1) // print the contents of the stack from top to bottom
			{
				countryStack.printStack();
				option = 0; //reset option back to 0
			}
			if(option == 2)
			{
				//always check condition of stack before popping, if stack is NOT empty, pop the top object and assign to variable to display to the user.
				if(!countryStack.Empty())
				{
					Country poppedObj = countryStack.pop();
					//Display the popped object to the user
					System.out.println("-- Popped: " + poppedObj.getName() + " from the Stack -- \n");
				}
				//The stack IS empty, therefore no elements can be popped. No action taken to stack and inform the user.
				else
					System.out.println("No Country can be popped from stack, the Stack is currently Empty! \n");

			}
			if(option == 3) //user wishes to add a country to the stack
			{
				//prompt the user for the 6 data fields.
				Scanner pushScan = new Scanner(System.in);
				System.out.println("Enter Country Name: ");
				String name = pushScan.nextLine();
				System.out.println("Enter Country Capital Name: ");
				String capital = pushScan.nextLine();
				System.out.println("Enter Country Population: ");
				double pop = pushScan.nextDouble();
				System.out.println("Enter Country's GDP: ");
				double GDP = pushScan.nextDouble();
				System.out.println("Enter Country's Area: ");
				double area = pushScan.nextDouble();
				System.out.println("Lastly, enter Country's Happiness Index: ");
				double hapIndex = pushScan.nextDouble();
				
				//always check if stack is full before pushing, if NOT full, pass the 6 data fields to an object to push onto stack.
				if(!countryStack.Full()) 
				{
					Country pushObj = new Country(name, capital, pop, GDP, area, hapIndex);
					countryStack.push(pushObj);
					System.out.println("-- Country: " + pushObj.getName() + " added to the Stack -- \n");
				}
				else
					//The stack IS full, therefore no push action is taken and user is informed about the state of stack array.
					System.out.printf("Country Cannot be added: Stack is full! please make space before adding! \n");
				option = 0;
			}
			if(option == 4)
			{
				//print contents of Priority Queue from the front to the rear, with front having the element of the highest priority in the array.
				countryPQueue.printPQueue();
				option = 0;
			}
			
			if(option == 5)
			{
				//check before performing remove, if NOT empty, remove the element from the front with the highest priority and inform user. 
				if(!countryPQueue.qEmpty())
				{
					Country removeObj = countryPQueue.remove();
					System.out.println("-- Country: " + removeObj.getName() + "  Removed from the Priority Queue -- \n");
				}
				else
					//Priority Queue is empty, therefore no actions taken and the user is informed of about the state of the Priority Queue Array.
					System.out.println("No Country can be removed from the Priority Queue, the Priority Queue is currently empty! \n");	
				option = 0;
			}
			
			if(option == 6) // user wishes to add to the priority queue
			{
				//prompt the user for the 6 data fields
				Scanner insertScan = new Scanner(System.in);
				System.out.println("Enter Country Name: ");
				String name = insertScan.nextLine();
				System.out.println("Enter Country Capital Name: ");
				String capital = insertScan.nextLine();
				System.out.println("Enter Country Population: ");
				double pop = insertScan.nextDouble();
				System.out.println("Enter Country's GDP: ");
				double GDP = insertScan.nextDouble();
				System.out.println("Enter Country's Area: ");
				double area = insertScan.nextDouble();
				System.out.println("Lastly, enter Country's Happiness Index: ");
				double hapIndex = insertScan.nextDouble();
				
				//check if priority queue is full before adding IF NOT full, pass the 6 data fields to an object to insert into the Priority Queue based on the Hap Index Value given. 
				if(!countryPQueue.qFull())
				{
					Country insertObj = new Country(name, capital, pop, GDP, area, hapIndex);
					countryPQueue.insert(insertObj);
					System.out.println("-- Country:  " + insertObj.getName() + " added to the Priority Queue -- \n");
				}
				else
					//Piority Queue is full, therefore insert cannot be completed. Inform user of the current state of Priority Queue Array. 
					System.out.printf("Country Cannot be added: Priority Queue is full! please make space before adding! \n");
				option = 0;
				
			}
			if(option == 7)//user selected the 7th menu option closing the program.
			{
				System.out.println("Thank you and goodbye! Exiting now.....");
			}
			else if(option > 7 || option < 0)//Value entered is outside of range.
			{
				System.out.println("Invalid Option Selection, please enter an integer value between 1 - 7");
			}
			
		} while (option !=7);
		scanner.close();
		
	}
	
	public class MenuPrinter
	{
		/**
		 * <p>This method is invoked after the user has entered a valid file name and both stack and queue has been populated </p>
		 * 
		 * This function presents the user with the menu that they can choose from in order to determine the type of action they wish to perform
		 * with the stack and priority queue. The value of record count from main is passed here to inform the user the number of times the first while loop
		 * iterated to ensure that the number of elements read from the csv file is accurate as its parsed onto the stack and queue.
		 * 
		 * 
		 * 
		 * @param recordCount - the variable holding the number of countries stored in the array
		 */
		public static void menu(int recordCount)
		{
			System.out.println("\n\nCOP3530 Project 2");
			System.out.println("Author: Calvin Villanueva (N01068487)");
			System.out.println("\nNumber of records read from csv to Stack: " + recordCount);
			System.out.println("Number of records read from csv to Priority Queue: " + recordCount);
			System.out.println("\nPlease Select an option between 1 - 7\n"+
								"1 - Print Stack \n"+
								"2 - Pop a Country from Stack \n"+
								"3 - Push a Country to Stack \n"+
								"4 - Print the Priority Queue \n"+
								"5 - Remove a Country from Priority Queue \n"+
								"6 - Insert a Country to the Priority Queue \n"+
								"7 - Exit Program\n\n");		
		}
	}

}

