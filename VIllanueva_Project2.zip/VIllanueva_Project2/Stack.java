/**
 * @author Calvin Villanueva
 * @version 10/06/2023
 * <p>
 * This is the Stack class for project 2. It is predominantly in charge of invoking the user's selected actions to the stack array.
 * When the program is executed and a valid file name has been provided, the 1st while loop in Project 2 uses the push function to 
 * add the country object in each line from the csv onto the stack. when the stack is populated, this will increment the value of top
 * up to the number of objects pushed on to the stack. This means that we can use the value of top to add or remove countries onto the stack
 * as the last element to be inserted is where top would point to. The Empty and Full boolean functions are primarily used in the Project 2 class in order
 * to follow the proper procedures we should take before pushing or popping from the stack (checking if the stack is full or empty before performing operation)
 * </p>
 * 
 * <p>
 * The methods invoked here are mostly based off of Chapter 4 part 1, Stacks and Queues, following the same logical steps for push,pop,Empty,and Full.
 * </p>
 * <b>Reference: Chapter 4 part 1, Stacks, Slide 8 - 9 (Implementing Stack functionality (Push and Pop))</b>
 * 			  
 */

public class Stack 
{
	private int maxSize; //variable to hold the size of the array
	private Country[] countryStack;
	private int top; //variable to indicate the TOP of the stack
	
	public Stack(int s) //constructor (s holds the size value we specified in project2.java (150))
	{
		maxSize = s; //set array size
		countryStack = new Country[maxSize];//create the Stack array with the specified size from Project2.java
		top = -1;
	
	}
	/**<p>
	 * This push method is the stack function responsible for adding countries onto our stack. It does so by following the Stack characteristic of Last in, first out,
	 * meaning that the last object to be inserted should always be at the top, similarly to adding onto a stack of envelopes.Additionally, when the user selects the stack 
	 * function to push a new country onto a stack, the new country, since after providing the data points will be the latest addition, should be pushed on the top of the stack 
	 * after the csv country objects. When push is performed, the "top" iterator is first incremented up, then the object is pushed onto the stack.
	 * </p>
	 * 
	 * <p>
	 * Before this method is invoked, it is assumed that we have checked the stack array to make sure it is not full before adding a new element onto the stack
	 * array.
	 *</p>
	 * 
	 * @param country - The Country Object being pushed into the stack
	 */
	public void push(Country country)
	{
		countryStack[++top] = country;
	}
	
	/**
	 * <p>
	 * The pop method is the stack function responsible for removing countries from our stack array. It follows the LIFO characteristics that Stacks possess by only
	 * popping the latest object to be added onto the stack array. Whether the last object from the csv file, or the last object to be pushed onto the stack array.
	 * When a pop is performed, the latest object where "top" is located at is popped from the stack and "top" is then decremented by 1 to go to the next new element that is now
	 * the new top.
	 * </p>
	 * 
	 * 
	 * <p>
	 * Before this method is invoked, it is assumed that we have checked if the stack array is empty before performing the pop operation to ensure we aren't trying to
	 * remove from an empty stack array.
	 *</p>
	 * 
	 * @return Country - The Country Object being popped from the stack
	 */
	public Country pop()
	{
		return countryStack[top--];
	}
	/**
	 * <p>
	 * The Empty method is the function used to check if the Stack array is currently empty. it does so by checking the value of the "top" iterator as this variable will
	 * indicate when the stack is empty and all objects has been popped, as the value of "top" will be - 1. If the value of top is such, then the method returns true
	 * to indicate that the stack is empty. From this boolean, we can inform the user that a pop operation cannot be performed due to the state of the stack array.
	 * </p>
	 * 
	 * 
	 * @return - True/false depending on if the stack is empty. 
	 */
	public boolean Empty()
	{
		return (top == -1);
	}
	/**
	 * The full method is the function used to check if the Stack array is currently full. It does so by checking the value of top and comparing it to the Stack array's
	 * Max size value - 1. If top does equal this value, then the method returns true to indicate that the Stack array is fully populated. From this boolean value, we can inform
	 * the user that a push cannot be performed due to the current state of the stack array.
	 * 
	 * 
	 * @return True/false depending on if the stack is full
	 */
	public boolean Full()
	{
		return (top == maxSize - 1);
	}	
	/**
	 * This is a slightly modified version of the print function from Project 1 option 1. It is placed within the Stack class to print the values of country
	 * stack from the top down, meaning that the top most element should be the last element to be added on to the stack (at the top of the stack), while the first element should be at the
	 * bottom of the stack. Here we use the value of top since the top will always point to the latest country object that was added in the stack, from here, we can just decrement down 1 by 1
	 * to list the country object in accordance to the Last in first out order.
	 * 
	 * This function also prompts the user with the number of elements currently stored in the stack array to keep track of the number of objects
	 * stored in the stack. Since this function merely prints the contents of the stack using the printCountyObj in Country.java, it does not modify the contents of the
	 * stack in any way.
	 * 
	 */
	public void printStack()
	{
		

		System.out.println("NAME                                     Capital                                GDPPC       APC               Happiness Index");
		System.out.println("-------------------------------------------------STACK-TOP-------------------------------------------------------------------");
		
		for(int i = top; i >= 0; i--)
		{
			countryStack[i].printCountryObj();
		}
		System.out.println("-------------------------------------------------STACK-BOTTOM----------------------------------------------------------------");
		System.out.println("Total Number of Elements in Stack: " + (top + 1));
	}
}
