/**
 * @author Calvin Villanueva
 * @version 10/06/2023
 * <p>
 * This is the PriorityQ class for project 2. It is mostly in charge of invoking the user's selected action from the menu on to the priority queue array.
 * When the program runs and a valid file name has been given, the first while loop in Project2.java inserts the contents of the csv file onto the priority queue
 * array using the value of the happiness index as the indicator of priority, with the higher happiness index having greater priority. When insertion is performed,
 * since priority queue is an abstract data structure, the objects of the highest priority is actually placed at the bottom of the array, inserting the objects in
 * ascending order. By arranging the array this way, we can achieve the project requirement of O(1) removals since the highest priority item will always be at the end
 * of the array and no elements needs to be shifted afterwards. Additionally, our insert method also achieves the project requirement of O(n) insertion as the for loop
 * in the insert method will always have to travel down the array and compare the element to be added against the elements already in the priority queue array to find
 * the correct place to insert. Since our Priority Queue is now set up this way to achieve the insertion/removal requirements, we then treat the end of our array as the
 * "front" of our priority queue where we will remove from to prioritize elements of the highest priority, and the start of our array as our "rear" where the last elements
 * to prioritize should be located. The PriorityQ class also contains methods to check if the priority queue array is full/empty so that we can check the state of the
 * priority queue before performing an insertion / removal action. 
 * </p>
 * 
 * <p>
 * The methods invoked here are mostly based off of Chapter 4 part 2, Priority Queues, following the same logical steps for Insert,Remove,Empty,and Full.
 * </p>
 * 
 * 
 * <b>Reference: Chapter 4 part 2, Priority Queues, Slide 6 - 8 (implementing Priority Queue Functionalities (Insert and Remove))</b>
 * 			  
 */
public class PriorityQ 
{
	private int maxSize; //variable to hold the size of the array
	private Country[] countryPQueue;
	private int nItems;
	
	public PriorityQ(int s) // constructor (s holds the value we specified in project2.java to use as our size for Priority Queue.)
	{
		maxSize = s; //pass value of s to maxSize to use as our array size. 
		countryPQueue = new Country[maxSize];
		nItems = 0;
		
		
	}
	/**
	 * <p>
	 * The insert method is the Priority Queue method in charge of inserting country objects onto our Queue based on their priority order. Since
	 * the happiness index value is what dictates the level of priority the country has compared to others, we use this value to determine how we insert
	 * onto the priority queue. Since the example provided from Chapter 4 part 2 inserts the elements in descending order, we simply changed the insertion to
	 * check if the country's happiness index to be added is less than the country already in the priority queue instead of greater than to sort them in ascending
	 * order. By arranging our priority queue this way, we can achieve the requirement of O(1) removals and O(n) insertion.  
	 * </p>
	 * 
	 * 
	 * @param country - The Object to be inserted onto our priority queue
	 */
	public void insert(Country country) 
	{	
		int j;
		if(nItems == 0)
		{
			countryPQueue[nItems++] = country;
		}
		else
		{
			for(j = nItems - 1; j >= 0; j--)
			{
				if(country.getHapIndex() < countryPQueue[j].getHapIndex())
					countryPQueue[j + 1] = countryPQueue[j];
				else
					break;
			}
			countryPQueue[j + 1] = country;
			nItems++;
		}
	}
	/**
	 * For Remove, since our Priority Queue is sorted in ascending order, meaning that our highest priority elements are located at the end of the array
	 * (done to achieve an O(1) removal) and the lowest at the beginning, the end of the Array is now considered our "front" where we remove from. When the csv file is
	 * parsed and correctly inserted based on happiness index onto our priority queue, we can simply use the index value of nItems to remove our country object as the 
	 * country object in that position should be the highest priority object for us to remove. When we remove from the end of the array, we dont have to shift the elements and
	 * just decrement nItems by 1 to go to the next highest priority object achieving our goal of O(1) removals. 
	 *
	 *
	 * @return Country - The country object that has the highest priority in the Priority Queue array. 
	 */
	public Country remove()
	{
		return countryPQueue[--nItems];
	}
	
	/**
	 * <p>
	 * The qFull method is the function used to check if the Priority Queue array is currently full. It is done by comparing the value of nItems and comparing it to the variable of
	 * maxSize, which holds the value passed from when we declared the array size in project2.java (150). if nItems does equal maxSize, then this indicates that our Priority Queue
	 * is full. We can use the value held by nItems as nItems always increments up whenever an insertion operation is completed, regardless if insertion is done by parsing the csv
	 * or by manually inserting a new country onto the priority queue array. When nItems equals maxSize (150) the method returns a true value. from this value, we can indicate to the
	 * user that an insert operation cannot be completed due to the state of the priority queue array.
	 * </p>
	 * 
	 * 
	 * @return True/false depending on if the Priority Queue array is full
	 */
	public boolean qFull()
	{
		return (nItems == maxSize);
	}
	/**
	 * <p>
	 * The qEmpty method is the function used to check if the priority queue array is currently empty. This is done by checking the index value stored in nItems. Since nItems
	 * increments up after an insertion, whether the insertion is from the csv or the user adds a new country object, This variable will never equal 0 until all objects have been
	 * removed from the Priority Queue array. When nItems does equal 0, this method returns a True value to indicate that the priority queue is empty, the remove operation cannot be
	 * completed on an empty queue, and the user is provided an explanation as to the current empty state of the queue array.  
	 * </p>
	 * 
	 * 
	 * 
	 * @return - True/false depending on if the Priority Queue array is empty. 
	 */
	public boolean qEmpty()
	{
		return (nItems == 0);
	}
	/**
	 * 
	 * Similarly to the print method used in Stack.java, the printPQueue function is a derivative version of the print method used from Project 1. This method is placed within
	 * the PriorityQ class to print the values of the Country Priority Queue from "front" to "rear". Since we treat the end of our array as the "front" of our priority queue,
	 * which implies that the highest priority objects are located here, then we can use the index value of nItems - 1 to print the object from the front of the queue and decrement
	 * by 1 till we reach the rear of the priority queue where the least priority objects should be located. 
	 * 
	 * This method also prompts the user with the number of elements currently stored in the priority queue by using the value of nItems, since this value will fluctuate up or down
	 * in value depending if an insert or a removal is performed. Since this method just prints the contents of the priority queue array, it does not modify the contents of the 
	 * Priority Queue array in any way, but instead simply treats the array as an abstract data type.
	 * 
	 * 
	 */
	public void printPQueue()
	{
		
		System.out.println("NAME                                     Capital                                GDPPC       APC               Happiness Index");
		System.out.println("-------------------------------------------------PQUEUE-FRONT----------------------------------------------------------------");
		
		for(int i = nItems - 1; i >= 0; i--)
		{
			countryPQueue[i].printCountryObj();
		}
		System.out.println("-------------------------------------------------PQUEUE-REAR-----------------------------------------------------------------");
		System.out.println("Total Number of Elements in Priority Queue: " + nItems);
	}
}
