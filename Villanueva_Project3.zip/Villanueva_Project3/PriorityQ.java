/**
 * @author Calvin Villanueva
 * @version 10/27/2023
 * <p>
 * This is our doubly linked list for our sorted priority queue for Project 3. The original base code used for the priority queue is derived from project 2 and has been modified to be implemented as a 
 * doubly linked list sorted priority queue instead of using an array. Since the initialization of linked lists are similar to one another, we modeled our implementation similarly to how we implemented the
 * double ended singly linked list for our stack. However, since we are implementing a doubly linked list, we consider forward and backward traversal through our links with the presence of 'next' and 'previous'.
 * Our implementation closely follows the logical concept of doubly linked list demonstrated in our textbook on Chapter 5, page 226 - 230, "doublyLinked.java". Like our double ended singly linked list in stack,
 * we still consider the the start and end of our linked list by using 'first' and 'last' as our reference. This is because one of the main characteristics of a doubly linked list is its efficiency when it comes
 * to insertion at either ends. in order to achieve an O(1) for both ends, we must maintain the value of 'first' and 'last' to use as our reference for insertion. The maintenance of these pointers are also crucial
 * for deletes as well, as proper maintenance of the pointers help us achieve O(1) removals if we were to remove from either end of the linked list. The traditional methods of previous priority queue still remains
 * on our current version similarly to stack, however the queue methods such as insert and remove invoke an inner class method for link insertion rather than our traditional operation in order to consider how insertion/
 * deletion is done within a doubly linked list. 
 * </p>
 * 
 * <p>
 * When the program is compiled and ran, and a valid file name has been given, the first loop on Project 3.java is invoked to populate the stack with appropriate countries we only wish to consider (Happiness Index >= 4.00).
 * Once the stack filters out unwanted objects and all elements from the csv has been parsed, after the contents of the stack has been displayed to the user, the stack then pops its contents from top to bottom onto our 
 * priority queue. As objects are popped from the stack onto our queue, our insertFirstLastAfter is predominantly in charge of properly inserting objects into the queue, sorting them based on the given happiness index value,
 * with the higher value being prioritize to the front out our queue. (descendingly sorted). Our insert method is derived from "doublyLinked.java" combining the logic of "insertFirst" and "insertLast" and by adding logic to 
 * insert before current similarly as to how it is performed on Quiz 6 - Doubly Linked List to account for middle insertions. Additionally, as insertion takes place at either ends to sort our doubly linked list, we maintain the
 * pointer values of 'first' and 'last'. Through this combined implementation, this means that insert method inserts O(N) as directed in the project instruction. Additionally, in the best case scenario, where our insert method only
 * has to insert at either ends, our insert method reaches a time complexity of O(1) since adding links to either ends remain constant through the use of the 'first' and 'last' pointers.
 * </p>
 * 
 * <p>
 *  As for our remove method, it is mostly based off of removeFirst from "doublyLinked.java" in order to achieve the removal requirement of O(1) as instructed. This is because as elements are sortedly placed onto the priority queue,
 *  the element that is placed at the very front of the queue will be pointed at by 'first' indicating that the element located here is at the top priority to remove from the queue. When remove occurs, the element at the beginning of 
 *  the queue is removed and the next element is reassigned as the new first. Since deletion takes place at the beginning and no shifting has to occur within linked list and reassignments of pointers are all constant time, our delete
 *  method removes with a time complexity of O(1). Although it is important to note that we don't actually use this method at all in the current moment since our menu option uses interval delete instead of deleting one by one from either
 *  ends. However if the need arises to remove elements from the queue from the start one at a time, we can easily call this method to perform such action. As for our intervalDelete, the logic used in this method is based off of the similar
 *  implementation used in the textbook example "Deleting an arbitrary link" on page 225 and the method implementation "deleteKey" on page 228 - 229, Chapter 5, Doubly Linked List. When this method is invoked from the menu, the program prompts
 *  the user to enter an interval range to delete from the priority queue, if a valid interval has been given, the interval value is passed onto intervalDelete in order to traverse and compare the happiness index value of elements within the queue
 *  find the start and the end of the deletion based on the interval given. If elements are found within that range, intervalDelete returns true and the user is informed that elements within that given interval has been removed from the queue. Otherwise
 *  a false value is returned and the user is then informed that no elements within that range was found/deleted. Although we don't have a time complexity specification for intervalDelete, since we have to traverse through the links to find where our interval
 *  begins and ends, we can assume that this operation takes O(N) to find the correct interval to delete. Lastly, similarly to how we implemented the recursive print on our stack, we use a similar approach for our priority queue since our operations properly
 *  maintains the 'first' and 'last' pointers to use as our base case/recursive case. 
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 221 - 230, "doublyLinked.java"
 *  <li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 215 - 217, "sortedList.java"
 *  <li><b>Recursion </b> - Chapter 6 Slide 2, Recursive method example
 * 	<li><b>Linked List</b> - Chapter 5 Part 1 & Part 2 slides.
 *  <li><b>Quiz 6</b> - Doubly Linked List Chapter 5 part 2 quiz. (doubly linked list insertion/deletion)  
 * <ol>
 * </p>
 */
public class PriorityQ 
{
	//constructor to initialize our doubly linked list
	public DoublyLinkList doublyLinkList;
	public PriorityQ()
	{
		doublyLinkList = new DoublyLinkList();
		
	}
	/**
	 * The insert method for our priority queue that invokes insertFirstLastBefore to sort and insert links based on their happiness index values in descending order.
	 * 
	 * @param country
	 */
	public void insert(Country country) 
	{	
		doublyLinkList.insertFirstLastBefore(country);
	}
	/*
	 * The currently unused method for our priority queue to remove links from our priority queue one by one starting at the element of the highest priority indicated by 'first'. If the need ever calls to remove
	 * from the front of the queue one by one, we can use this method to implement such operation. 
	 */
	public DoublyLink remove()
	{
		return doublyLinkList.remove();
	}
	/*
	 * The boolean method for our priority queue that invokes isEmpty from our doubly linked list to check if our priority queue is empty based on the condition of 'first'
	 */
	public boolean qEmpty()
	{
		return doublyLinkList.isEmpty();
	}
	/**
	 * As for our printPQueue function, we created a new method to call on to recursively print our queue like we did in the stack class to meet the project requirement of recursive print. We pass the 
	 * maintained value of 'first' onto our recursive method to use as 'current' to indicate the start our queue, as 'first' will point to the element of the highest priority. the value of 'first' is used
	 * as the condition for our recursive/base case for our recursive print.
	 */
	public void printPQueue()
	{
		
		System.out.println("NAME                                     Capital                                GDPPC       APC               Happiness Index");
		System.out.println("-------------------------------------------------PQUEUE-FRONT----------------------------------------------------------------");
		recursivePQ(doublyLinkList.first);
		System.out.println("-------------------------------------------------PQUEUE-REAR-----------------------------------------------------------------");
		
	}
	/**
	 * Our recursivePQ, similarly to recursiveStack, is primarily based off of Chapter 6 slide 2 to use as our baseline condition for our recursive/base case. When recursivePQ is called from printPQueue, we
	 * pass the reference value of 'first' to use as 'current' since 'first' will always indicate the element of the highest priority. so long as 'first'/'current' does not equal null, this means that we can keep
	 * recursively iterating until this condition is met to indicate the end of our priority queue. for every recursive call made, 'current.next' is passed to the method itself to move to the next link after current
	 *  (our recursive case) until the end of the queue is reached (our base case)
	 * 
	 * @param current
	 */
	public void recursivePQ(DoublyLink current)
	{
		if (current == null) //base case
		{
			return;
		}
		else // recursive case
		{
			current.data.printCountryObj();
			recursivePQ(current.next);
		}
	}
	/**
	 * The DoublyLink class is used to represent the elements within our doubly linked list. our country object is passed to Data to hold the reference values of our country objects from the CSV file.
	 * Additionally, we also initialize next and previous to allow forward and backward traversal through our doubly linked list. The logic and main functionalities used here are primarily based off a similar
	 * approach taken with our double-ended singly linked list stack and the example demonstrated on "doublyLinked.java" on page 226 - 230, demonstrating the implementation of a doubly linked list. 
	 * 
	 */
	class DoublyLink
	{
		public Country data;
		public DoublyLink next;
		public DoublyLink previous;
		
		/**
		 * The DoublyLink constructor to initialize data with a given country object as well as initially setting next and previous to null.
		 * 
		 * @param country
		 */
		public DoublyLink(Country country)
		{
			data = country;
			next = null;
			previous = null;
		}
		
	}
	/**
	 * The DoublyLinkList class is the class that represents our doubly linked list required to transform our priority queue to use a linked list instead of an array. the class initializes
	 * our first and last pointers to use and maintain throughout our operations in order to properly follow the implementation of a doubly linked list. By maintining the values of 'first' and 
	 * 'last' throughout our operations, we can benefit from insertion and deletion at either ends with a best case scenario of O(1). the values of 'first' and 'last' is always considered and maintain
	 * whenever insert/delete/intervalDelete operations are performed. 
	 * 
	 */
	class DoublyLinkList
	{
		private DoublyLink first;
		private DoublyLink last;
		
		/**
		 * Constructor to initialize first and last to null for our doubly linked list.
		 * 
		 */
		public DoublyLinkList()
		{
			first = null;
			last = null;
		}
		/**
		 * The isEmpty method, similarly to how it's used in stack, simply checks if the doubly linked list is empty by checking the current value of first. If first = null, then isEmpty returns 
		 * true to indicate the state of the priority queue, else it returns false. 
		 * 
		 * @return True if first = null indicating an empty doubly linked list priority queue
		 */
		public boolean isEmpty()
		{
			return (first == null);
		}
		/**
		 * The insertFirstLastBefore method is a combined method derived from "doublyLinked.java" on page 226 - 230 Quiz 5 question regarding doubly linked list, and "sortedList.java" on page 215 - 217 in order
		 * to implement an insertion that sorts the priority queue based on the happiness index value of the countries being inserted into it from the stack. When insertion is first performed, the priority queue 
		 * first checks if the linked list is currently empty to ensure proper reassignment of 'first' and 'last' to the new link being inserted. then, once this link is inserted, the subsequent countries being inserted 
		 * will then be checked based on their happiness index value to determine if the new country being inserted belongs to the beginning to make our new 'first', the end to make our new 'last' or in the middle right
		 * before current. based on the placement, the links are reassigned in order to properly maintain and sort the values from the highest priority to the lowest, which will be indicated by 'last'.
		 * 
		 * 
		 * @param country 
		 */
		public void insertFirstLastBefore(Country country)
		{	
			DoublyLink newLink = new DoublyLink(country);
			DoublyLink previous = null;
			DoublyLink current = first;
			
			
			if(qEmpty())
			{
				first = newLink;
				last = newLink;
				return;
			}
			
			
			while(current != null && country.getHapIndex() < current.data.getHapIndex())
			{
				previous = current;
				current = current.next;
			}
			if (previous == null)
			{
				first.previous = newLink;
				newLink.next = first;
				first = newLink;
			}
			else if(current == null)
			{
				last.next = newLink;
				newLink.previous = last;
				last = newLink;
			}
			else
			{
				newLink.next = current;
				previous.next = newLink;
				newLink.previous = previous; 
				current.previous = newLink; 
					
			}
		}
		/**
		 * Our remove method is similarly implemented as deleteFirst from our stack and deleteFirst from "doublyLinked.java". it achieves a time complexity of O(1) since once the elements are inserted onto
		 * the priority queue, 'first' will always indicate the start or front of our queue where our highest priority country is located. since removal is occurring at the beginning of our linked list, removals
		 * and reassignment of pointers are all constant time, thus resulting in an O(1) removal operation. Similarly to our stack, when 'first' is removed, 'first.next' becomes the new 'first' and the old 'first' is 
		 * passed to a temp variable to return similar to pop in the stack class. Our remove however is not used in this project as we rely on interval delete to remove from the priority queue, however if the need 
		 * ever arises to remove from the front of our queue one by one, we can invoke and refer to this method to do such operation. 
		 * 
		 * 
		 * @return temp The element of the highest priority being removed from the priority queue
		 */
		public DoublyLink remove() 
		{
			
			if(qEmpty())
			{
				return null;
			}
			DoublyLink temp = first;
			if (first.next == null)
			{
				last = null;
			}
			else
			{
				first.next.previous = null;
			}
			first = first.next;
			return temp;
		}
		/**
		 * our intervalDelete method is mostly based off of the "deleteKey" method found in "doublyLinked.java" and deleting an arbitrary link from chapter 5 on the textbook. It modifies "deleteKey" to take
		 * the interval values given by the user from project3.java to use as the lower bound and upper bound interval of happiness index to remove from our priority queue. Before deletion of the given interval
		 * is performed however, a conditional check in Project3.java first ensures that the values given are of numeric type and that the first interval is not > the second. When a proper interval is provided,
		 * a while loop is used to traverse through the link starting with 'first' and comparing the happiness index value of the countries in the priority queue to find the lower bound and upper bound to delete.
		 * if a country was found within the given interval, their links are removed from the priority queue effectively removing and deleting them from our list and intervalDelete returns a boolean value of true
		 * and prompting the user that countries within the given range has been removed, otherwise a false value is returned and the user is prompted that no countries were found to delete within the given range.
		 * If the given interval range indicates deletion at the beginning or end of the doubly linked list, then the reference value of 'first' is continuously passed to the next country until the country that 
		 * 'first' is pointing to falls outside the interval delete range. as for intervalDelete in the end, a similar approach is taken with last. as last continues to traverse backwards by using previous until 
		 * 'last' is pointing at an element that is outside the interval delete range. Through this, we can remove from the beginning, end, and middle of our priority queue while still maintaining the proper procedure
		 * to ensure 'first' and 'last' are correctly indicating the start and end of our linked list.
		 * 
		 * 
		 * @param int1 The lower bound of the interval to delete based on happiness index
		 * @param int2 The upper bound to delete based on happiness index
		 * @return intervalFound The boolean value to indicate if country within the given interval was found and deleted. 
		 */
		public boolean intervalDelete(double int1, double int2)
		{
			if (qEmpty())
			{
				return false;
			}
			boolean intervalFound = false;
			DoublyLink current = first;
			while (current != null)
			{
				if(current.data.getHapIndex() >= int1 && current.data.getHapIndex() <= int2)
				{
					if(current == first)
					{
						first = current.next;
					}
					else
					{
						current.previous.next = current.next;
					}
					if(current == last)
					{
						last = current.previous;
					}
					else
					{
						current.next.previous = current.previous;
					}
					intervalFound = true;
				}
				current = current.next;
			}
			return intervalFound;
		}
	}
}
