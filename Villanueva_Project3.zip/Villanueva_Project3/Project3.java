import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * @author Calvin Villanueva
 * @version 10/27/2023
 * 
 * <p>
 * This is the driver class for Project 3. Main is primarily in charge of handling and parsing the data from countries3.csv and storing the data onto a
 * Double-ended singly linked list stack and a sorted Doubly Linked List based on the country's Happiness Index value. When we parse the value
 * to the linked lists, we only consider countries that have a happiness index value greater than or equal to 4.00 in order to only accept countries with 
 * good, very good, and excellent happiness index rating. Since we are using linked lists, we no longer have to worry about setting a size since
 * linked list's maximum size can dynamically change based on needs. Once the user enters the appropriate file name "Countries3.csv", the program uses
 * a while loop with an if condition to filter out the countries with < 4.00 happiness index rating. Once the appropriate countries are parsed onto the 
 * double-ended singly linked list stack, the stack content is printed from top to bottom before the elements is popped into the Doubly linked list Priority
 * Queue where the insert method used sorts the countries from the highest priority value to the lowest. Once all elements have been popped from the stack and
 * onto the Priority Queue, the contents of the priority queue is printed as well from the highest priority to the lowest. Once the contents of both linked lists
 * are shown to the user, the menu is then printed to allow the user to manipulate the contents of the priority queue. 
 * 
 * </p>
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing
 * 	<li><b>Double-Ended Lists - Textbook </b> - Chapter 5 Linked Lists, Page 198 - 201, "firstLastList.java"
 *  <li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 221 - 230, "doublyLinked.java"
 *  <li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 215 - 217, "sortedList.java"
 *  <li><b>Recursion </b> - Chapter 6 Slide 2, Recursive method example
 * 	<li><b>Linked List</b> - Chapter 5 Part 1 & Part 2. 
 *  <li><b>Quiz 6</b> - Doubly Linked List Chapter 5 part 2 quiz. (doubly linked list insertion/deletion)  
 * <ol>
 * </p>
 */

public class Project3 
{	
	/**
	 * <b>This is the main function of project 3</b>
	 * 
	 * <p>
	 * The main function is the driver class for project3 and is predominantly in charge 3 main components of Project3.
	 * </p>
	 * 
	 * <p>
	 * First it prompts the user to enter a file name to locate in order to parse it into our 2 linked lists. For this project, it will be "Countries3.csv". 
	 * Once a correct filename is received it skips the first line containing the header and uses a delimiter to know when a new line is detected within the CSV file
	 * </p>
	 * 
	 * <p>
	 * secondly, it then uses a while loop combined with an if statement to filter out and store the countries with the happiness index rating > 4.00 into the double-ended linked list
	 * stack. Once the end of the file is reached, the stack should contain all countries with the happiness index rating that is > 4.00 in an appropriate order following the LIFO rule of
	 * stacks. the content of this stack is then printed and presented to the user before the contents are popped , inserted and sorted onto the Priority Queue where the contents is once again
	 * printed to the user. The Priority Queue should show the user that the countries from the stack are now sorted based on their happiness index rating from the highest priority at the front
	 * of the queue to the lowest at the rear.
	 * </p>
	 * 
	 * <p>
	 * Then lastly, we can then present the user with the repeating menu until the user selects the 3rd menu option to quit the program. From this menu,
	 * The user can choose to remove countries from the Priority Queue based on the happiness index interval value given. If an appropriate interval is given,
	 * The countries with the happiness index value that is within the interval range given should now be removed from the priority queue once the user selects
	 * the option to print the contents of the priority queue again. 
	 * 
	 * <p>
	 * When the user selects the first option to delete countries based on the given interval, The user is prompted by the program to provide the lower bound and the upper bound.
	 * If the user enters an incorrect input such as a string or the user gives the a lower bound value thats > than the upper bound, the program prompts the user of the error and
	 * asks the user to try again. After the correct interval is given, the user is informed that the countries between the given intervals have now been removed from the Priority Queue.
	 * Additionally, the push and pop insert method invoked from the double-ended linked list stack class both have the time complexity of O(1) whilst the Doubly ended linked list's insert has
	 * a time complexity of O(N) and O(1) time complexity for removals. Lastly, when the contents of the stack and priority queue are printed, they are printed using a recursive method in order
	 * to meet the project requirements specified in project3.pdf. 
	 * </p>
	 * 
	 * 
	 * <p>
	 * The main function contains error handling when it comes to the user inputing an invalid file name and an invalid menu option. It also contains
	 * error handling for the first option of the menu to ensure that the interval values being given are of numeric type and that the first interval
	 * is not greater than the second interval.
	 * </p>
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		
		Stack countryStack = new Stack();
		PriorityQ countryPQ = new PriorityQ();
		

		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the name of the file to open (Countries3.csv) ");
		String fileName = input.next();
		System.out.println("Opening File: " + fileName);
		Scanner file = null;

		
		try
		{
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)//catch for invalud input
		{
			System.out.println("Error the file name entered cannot be found");
			System.exit(1);
			input.close();
		}
		
		file.nextLine();//skip the header!
		file.useDelimiter(",|\n");
		
		while(file.hasNext())
		{
			String name = file.next();
			String capital = file.next();
			double pop = file.nextDouble();
			double GDP = file.nextDouble();
			double area = file.nextDouble();
			double hapIndex = file.nextDouble();
			double gdppc = file.nextDouble();
			double apc = file.nextDouble();
			
			Country countryObj = new Country(name, capital, pop, GDP, area, hapIndex, gdppc, apc);	
			if(countryObj.getHapIndex() >= 4)
			{
				countryStack.push(countryObj);
			}
			
		}
		System.out.print("Stack Contents: \n");
		countryStack.printStack();
		System.out.print("End of Stack \n\n\n\n");
		//transfer stack content to pq
		while(!countryStack.Empty())
		{
			Country country = countryStack.pop().data;
			countryPQ.insert(country);
		}
		System.out.print("Priority Queue Contents: \n");
		countryPQ.printPQueue();
		System.out.print("End of Priority Queue \n\n\n\n");
		file.close();//close scanner
		Scanner scanner = new Scanner(System.in);
		int option = 0;

		do
		{
			//Prompt the user menu
			MenuPrinter.menu();
			
			try
			{
				option = scanner.nextInt();
				System.out.println("Option Selected: " + option);
			}
			catch(InputMismatchException e)//catch input that may not be digit
			{
				System.out.println("Invalid Option Selection, please enter a numeric value");
				scanner.next();
				option = 0;
			}
			
			if(option == 1)
			{
				double int1 = 0;
				double int2 = 0;
				boolean goodInterval = false;
				
				while(goodInterval == false)
				{
					try
					{
						System.out.print("Enter the first interval to delete from the priority queue: ");
						int1 = scanner.nextDouble();
						System.out.print("Enter the second interval to delete from the priority queue: ");
						int2 = scanner.nextDouble();
						
						while(int1 > int2)
						{
							System.out.print("Error! the first interval cannot be larger than the second interval.\n\n\n");
							System.out.print("Enter the first interval to delete from the priority queue: ");
							int1 = scanner.nextDouble();
							
							System.out.print("Enter the second interval to delete from the priority queue: ");
							int2 = scanner.nextDouble();
						}
						goodInterval = true;
					}
					catch (InputMismatchException e)
					{
						System.out.println("Invalid Option Selection, please enter a numeric value \n\n\n");
						scanner.next();
					}
				}
				
				boolean intervalFound = countryPQ.doublyLinkList.intervalDelete(int1, int2);
				if(intervalFound == true)
				{
					System.out.print("Countries between the interval of " + int1 + " and " + int2 + " has been removed from the Priorty Queue.\n");
				}
				else
				{
					System.out.print("No Countries were found between interval " + int1 + " and " + int2 + " ... \n");
				}
				option = 0; //reset option back to 0
			}
			if(option == 2)
			{
				countryPQ.printPQueue();
			}
				
			if(option == 3)//user selected the 7th menu option closing the program.
			{
				System.out.println("Thank you and goodbye! Exiting now.....");
			}
			else if(option > 3 || option < 0)
			{
				System.out.println("Invalid Option Selection, please enter an integer value between 1 - 3");
			}
			
		} while (option !=3);
		scanner.close();
		
	}
	
	public class MenuPrinter
	{
		/**
		 * <p>This method is invoked after the user has entered a valid file name and both stack and queue has been populated </p>
		 * <p>
		 * This function presents the user with the menu that they can choose from in order to determine the type of action they wish to perform
		 * with the stack and priority queue.
		 * </p>
		 * 
		 * @param recordCount - the variable holding the number of countries stored in the array
		 */
		
		public static void menu()
		{
			System.out.println("\n\nCOP3530 Project 3");
			System.out.println("Author: Calvin Villanueva (N01068487)");
			System.out.println("\nPlease Select an option between 1 - 3\n"+
								"1 - Enter a happiness interval for deletions on priority queue \n"+
								"2 - Print Priority Queue \n"+
								"3 - Exit Program\\n\\n");		
		}
	}

}

