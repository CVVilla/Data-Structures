/**
 * @author Calvin Villanueva
 * @version 10/27/2023
 * <p>
 * 	This is the country class for Project 3
 * </p>
 * 
 * <p>
 * 	The Country class is reused from Project 1 and has has been slightly modified to take in 2 additional fields added into the CSV file GDPPC and APC. 
 * </p>
 * <p>
 *  The Country class is predominantly in charge of retrieving the data contained in the double-ended singly linked list stack and doubly linked list sorted
 *  priority queue array. Since we only consider taking in countries with the happiness index value of 4.0 and greater (Countries with Good, Very good, and
 *  Excellent rating).The country class also contains the method for printing the country object(s) from 
 *  the array to display the values in a correct format to the user.   
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Read CSV File</b> - Dr. Liu 's example video - Utilized scanner method demonstrated for parsing
 * 	<li><b>Double-Ended Lists - Textbook </b> - Chapter 5 Linked Lists, Page 198 - 201, "firstLastList.java"
 *  <li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 221 - 230, "doublyLinked.java"
 *  <li><b>Doubly Linked Lists  - Textbook </b> - Chapter 5 Linked Lists, Page 215 - 217, "sortedList.java"
 *  <li><b>Recursion </b> - Chapter 6 Slide 2, Recursive method example
 * 	<li><b>Linked List</b> - Chapter 5 Part 1 & Part 2. 
 *  <li><b>Quiz 6</b> - Doubly Linked List Chapter 5 part 2 quiz. (doubly linked list insertion/deletion)  
 * <ol>
 * </p>
 * 
 */
public class Country 
{
	/**
	 * Constructor for making a country object with the specified attribute fields
	 * @param name - Country Name
	 * @param capital - Country Capital
	 * @param pop - Country Population
	 * @param GDP - Country GDP
	 * @param area - Country Area
	 * @param hapIndex - Country Happiness Index
	 * @param gdppc - Country GDPPC value
	 * @param apc - Country APC value
	 */
	private String name;
	private String capital;
	public double pop;
	public double GDP;
	public double area;
	public double hapIndex;
	public double gdppc;
	public double apc;
	
	/**
	 * This method is invoked upon the user selecting the 2nd option in the user menu in the 
	 * project3 class. In order to not edit the contents of the array and match the output of the examples
	 * the project3.pdf provides, we calculate the value of GDPPC and APC of each country being printed and
	 * display those values to the user. We use this calculated value instead of the given values on the new countries3.csv
	 * to minimize the changes made. 
	 * 
	 */
	public void printCountryObj()
	{
		
		System.out.printf("%-40s %-35s %10.3f %10.6f %18.3f%n", name, capital, GDP / pop, area / pop, hapIndex);
	}
	
	public Country(String name, String capital, double pop, double GDP, double area, double hapIndex, double gdppc, double apc)
	{
		this.capital = capital;
		this.name = name;
		this.GDP = GDP;
		this.pop = pop;
		this.area = area;
		this.hapIndex = hapIndex;
		this.gdppc = gdppc;
		this.apc = apc;
		
		
	}
	/**
	 * 
	 * @return - Country Name - Get the current country's Name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * 
	 * @param name - sets a name for country name (not used)
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	/**
	 * 
	 * @return - Country Capital - Get the current country's Capital Name
	 */
	public String getCapital()
	{
		return capital;
	}
	/**
	 * 
	 * @param capital - set a name for country capital (not used)
	 */
	public void setCapital(String capital)
	{
		this.capital = capital;
	}
	/**
	 * 
	 * @return - Country Population - Get the current country's population count
	 */
	public double getPop()
	{
		return pop;
	}
	/**
	 * 
	 * @param pop - set a country's population value (not used)
	 */
	public void setPop(double pop)
	{
		this.pop = pop;
	}
	/**
	 * 
	 * @return - Country GDP - Get the current country's GDP value
	 */
	public double getGDP()
	{
		return GDP;
	}
	/**
	 * 
	 * @param GDP - sets a country's GDP value (not used)
	 */
	public void setGDP(double GDP)
	{
		this.GDP = GDP;
	}
	/**
	 * 
	 * @return - Country Area - Get the current country's Area Value
	 */
	public double getArea()
	{
		return area;
	}
	/**
	 * 
	 * @param area - sets a country's Area value (not used)
	 */
	void setArea(double area)
	{
		this.area = area;
	}
	/**
	 * 
	 * @return Country Happiness Index - Get the current country's Happiness Index Value
	 */
	public double getHapIndex()
	{
		return hapIndex;
	}
	/**
	 * 
	 * @param hapIndex - sets a country's Happiness Index Value (not used)
	 */
	public void setHapIndex(double hapIndex)
	{
		this.hapIndex = hapIndex;
	}
	/**
	 * 
	 * @return Country gdppc - Get the current country's gdppc value (not used)
	 */
	public double getgdppc()
	{
		return gdppc;
	}
	/**
	 * 
	 * @return Country gdppc - set's the current country's gdppc value (not used)
	 */
	public void setgdppc(double gdppc)
	{
		this.gdppc = gdppc;
	}
	/**
	 * 
	 * @return Country apc - Get the current country's APC value (not used)
	 */
	public double getAPC()
	{
		return apc;
	}
	/**
	 * 
	 * @return Country apc - set's the current country's APC value (not used)
	 */
	public void setAPC(double apc)
	{
		this.apc = apc;
	}

}
