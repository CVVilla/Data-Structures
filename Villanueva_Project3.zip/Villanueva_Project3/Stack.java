/**
 * @author Calvin Villanueva
 * @version 10/27/2023
 * <p>
 * This is the Double-ended singly linked list stack for Project 3. It is derived from project 2 and has been modified to implement a double ended linked list instead of an array.
 * The modifications made to transform the stack array into a linked list is mostly derived and based off of the doubled-ended list demonstration from the textbook on page 198, Ch.5,
 * "firstLastList.java". The implementation of a double-ended singly linked list is similar to that of a traditional singly linked list, with the exception of the presence of the 'last'
 * pointer. Although since we are implementing a stack, thus the need to insert at the end is unnecessary, it is essential that we keep the presence of the pointer in order to maintain the 
 * project requirement of a Double-ended singly linked list stack.in addition to transforming the stack to use linked list instead of arrays, we removed obsolete functions such as isFull
 * since linked lists do not have a maximum size like an array. However, we still maintain functions such as push, pop and Empty that calls for inner functions such as insertFirst and deleteFirst 
 * to replace our traditional stack operations with operations that considers how a double-ended singly linked list should act.
 * </p>
 * 
 * <p>
 * When the program is compiled and ran, and a valid file name has been given (as prompted in project3.java) the first while loop in Project3.java is invoked and iterates continuously to push the country
 * objects onto the double-ended singly linked list. Within this while loop, an if condition is used in order to filter out countries with happiness index less than 4.00, as per project requirement states
 * that we only consider countries with happiness index rating of Good, VGood, and Excellent, which are countries with a happiness index value >= 4.00. When an object is being pushed / a link is being inserted
 * into the stack, the insertFirst method being invoked by push first checks if the linked list is empty in order to assign the 'last' or tail pointer to point to the first object in the stack, ensuring that our
 * first element is being maintained by the 'last' pointer. As more elements are pushed onto our stack, links are added behind the 'last' element and the last to be inserted is assigned the 'first' pointer. This
 * is done so that we can maintain and follow the concept principle of stack "last in, first out" as the last element to be inserted will be maintained by the 'first' pointer to be popped out, and the very first element
 * to be pushed in will be maintained by the 'last' pointer to indicate the last element to be popped from the stack. Since our pushes all takes place at the start of the link and our pop operation pops the element
 * pointed by 'first' to 'last' this means that both our operation takes O(1) in terms of time as insertion and deletion require no shifting of elements like a traditional array and reassignment of pointers are all
 * constant time.
 * </p>
 * 
 * <p>
 * The stack class has also been modified to print the contents of the stack recursively instead of iteratively like how it was performed in Project 2. The recursive print utilizes a similar logic demonstrated from
 * Chapter 6, Slide 2 within the class slide and uses the conditional value of 'current' within the linked list to use for our base/recursive case. So long as 'current' does not = Null, this means that our stack still
 * has contents within to print. Once the recursive print hits the end of our stack, 'current' will = to Null indicating that we have reached the end of our stack thus hitting our base case condition to quit the recursive
 * print
 * </p>
 * 
 * <p>
 * <b>Reference(s):</b>
 * <ol>
 * 	<li><b>Double-Ended Lists - Textbook </b> - Chapter 5 Linked Lists, Page 198 - 201, "firstLastList.java"
 *  <li><b>Recursion </b> - Chapter 6 Slide 2, Recursive method example
 * 	<li><b>Linked List</b> - Chapter 5 Part 1 & Part 2. 
 * <ol>
 * </p>
 */
public class Stack 
{
	//Constructor to initialize our linked list
	public LinkList linkList;
	public Stack()
	{
		linkList = new LinkList();
	
	}
	/**
	 * The Stack Push method that invokes the insertFirst Method to push an element at the 'top' of the stack or the beginning of the linked list. 
	 * 
	 * @param country
	 */
	public void push(Country country)
	{
		linkList.insertFirst(country);
	}
	/**
	 *  The Stack Pop method that invokes the deleteFirst method to pop the most recently added element from the stack following Last in - first out.
	 *  
	 * @return
	 */
	public Link pop()
	{
		return linkList.deleteFirst();
	}
	/**
	 * The Stack isEmpty method that checks if the linkedlist is empty to ensure proper insertion/removal for pop and push.
	 * @return
	 */
	public boolean Empty()
	{
		return linkList.isEmpty();
	}
	/**
	 * As for our printStack function, we created a new method to call on to recursively print our stack as instructed on the project requirement. to print recursively, we pass the 
	 * LinkList value of 'first' onto our recuresiveStack to use as 'current'. Based on the value of this variable, we can use this for our base/recursive case.
	 */
	public void printStack()
	{
		

		System.out.println("NAME                                     Capital                                GDPPC       APC               Happiness Index");
		System.out.println("-------------------------------------------------STACK-TOP-------------------------------------------------------------------");
		recursiveStack(linkList.first);
		System.out.println("-------------------------------------------------STACK-BOTTOM----------------------------------------------------------------");
		
	}
	/**
	 * Our recursiveStack is primarily based off of Chapter 6 Slide 2 to use as our baseline for the conditions for our base case and recursive case. When recursiveStack is called from printStack, we pass the
	 * reference value of 'first' to 'current'. by using the reference value of 'first', we can use this as our condition for our base case. This is because as long as current != Null, this indicates that we have
	 * not hit the end of our stack. thus displaying the value of current and passing current.next to recursiveStack once again to print the next element. Once current does = Null, this indicates the end of our
	 * Linked list reaching our base case goal. 
	 * 
	 * @param current The pointer reference of first.
	 */
	public void recursiveStack(Link current)
	{
		if(current == null)
		{
			return;
		}
		else
		{
			current.data.printCountryObj();
			recursiveStack(current.next);
		}
	}
	/**
	 * The Link class to represent the elements in the linked list. Data holds the reference value of our Country Objects and next to hold the reference value of the elements next to each other.
	 * The logic and main functionalities used in this class are primarily based off of the example code provided in the text book by firstLastList.java on pg 198 in Chapter 5, demonstrating the
	 * proper implementation of a double-ended singly linked list.
	 */
	class Link
	{
		public Country data;
		public Link next;
		
		/**
		 * Link Constructor that initializes data with a given Country object. Additionally, next is initialized to null.
		 * 
		 * @param country
		 */
		public Link(Country country)
		{
			data = country;
			next = null;
			
		}
	}
	/**
	 * The LinkList Class is the class that represents the double-ended singly linked list required for stack. It maintains the reference of the first and last elements of the list
	 * to ensure proper pointer reassignment whenever an action such as push/pop/print is performed.
	 */
	class LinkList
	{
		private Link first;
		private Link last;
		
		/**
		 * Constructor to initialize first and last for our double ended singly linked list
		 */
		public LinkList()
		{
			first = null;
			last = null;
		}
		/**
		 * The isEmpty method simply checks if the linked list is empty by checking the value of first. if first = null, then isEmpty returns true indicating an empty linked list.
		 * 
		 * @return True if linked list is empty (first = null)
		 */
		public boolean isEmpty()
		{
			return (first == null);
		}
		/*
		 * the insertFirst method from Chapter 5 firstLastList.java is an insert method that fits the need for our stack operation to push at the beginning of the array. The insertFirst method first checks 
		 * if our stack is empty. When the first element is pushed onto the stack, the first element is assigned to the 'last' pointer to keep reference of the very first element being pushed to the stack. 
		 * as more elements are pushed on the stack, the newly added elements are assigned as the insertion continues. at the end of this operation, the very last element to be inserted will be pointed at by
		 * 'first' indicating the first element to be popped from our stack, and the first element ever pushed being pointer at by 'last' to indicate the last element to be popped from the stack inorder to follow
		 * the "last in, first out" concept of stacks. 
		 * 
		 */
		public void insertFirst(Country country)
		{
			Link newLink = new Link(country);
			if (isEmpty())
			{
				last = newLink;
			}
			newLink.next = first;
			first = newLink;
		}
		/**
		 * Our deleteFirst function removes the most recently added element from the linked list using the reference value of first. before remove is performed, we first check if the stack is empty, 
		 * if not, then we pass the reference value of first to a temp variable to return to simulate stack's pop function. Once the value is passed, we then reassign the next element(first.next) to become
		 * our new first, essentially forgetting and deleting about the original first. if first.next was null, meaning that there is only one item left on our list, then we update last to also = null to indicate
		 * the end of the list.
		 * 
		 * @return temp - the element that was removed from the stack
		 */
		public Link deleteFirst()
		{
			if (isEmpty())
			{
				return null;
			}
			Link temp = first;
			if(first.next == null)
			{
				last = null;
			}
			first = first.next;
			return temp;
		}
	}
}

